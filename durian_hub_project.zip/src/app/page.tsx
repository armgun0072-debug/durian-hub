"use client";

import React, { useState, useMemo, useEffect } from "react";
import {
  ShieldCheck,
  Sprout,
  Store,
  Scissors,
  MapPin,
  Calendar,
  Search,
  MessageSquare,
  Star,
  ArrowLeft,
  Share2,
  Copy,
  AlertTriangle,
  Send,
  Plus,
  CheckCircle2,
  LogOut,
  UserCheck,
  FileCheck2,
  BarChart3,
  Layers,
  Sparkles,
  Info,
  Clock,
  ChevronRight,
  Upload,
  X,
  Mail,
  KeyRound,
  RefreshCw,
  ExternalLink,
  Lock,
  Handshake,
} from "lucide-react";
import {
  REGIONAL_SEASONS_DATA,
  VARIETY_STRIP_ITEMS,
  INITIAL_POSTS,
  QUICK_REPLY_CHIPS,
  INITIAL_ROLE_REQUESTS,
  RoleType,
  PostType,
  MarketplacePostItem,
  ChatRoomItem,
  RoleVerificationItem,
} from "@/data/mockData";

const ROLE_CONFIG: Record<
  RoleType,
  {
    title: string;
    shortTitle: string;
    subtitle: string;
    badgeBg: string;
    accentText: string;
    allowedPostType: PostType;
    actionLabel: string;
  }
> = {
  SELLER: {
    title: "ผู้ขายทุเรียน (ชาวสวน)",
    shortTitle: "ชาวสวนผู้ขาย",
    subtitle: "ประกาศขายผลผลิตหน้าสวน ตรวจสอบราคารับซื้อหน้าล้ง และดีลกับล้งโดยตรง",
    badgeBg: "bg-emerald-50 text-emerald-700 border-emerald-200",
    accentText: "text-emerald-700",
    allowedPostType: "SELL",
    actionLabel: "ลงประกาศขายทุเรียนหน้าสวน",
  },
  BUYER: {
    title: "ผู้ซื้อทุเรียน (ล้ง / พ่อค้า)",
    shortTitle: "ล้งรับซื้อ",
    subtitle: "ตั้งราคารับซื้อหน้าล้งประจำวัน ค้นหาสวนพร้อมตัด และเจรจาซื้อขาย",
    badgeBg: "bg-sky-50 text-sky-700 border-sky-200",
    accentText: "text-sky-700",
    allowedPostType: "BUY",
    actionLabel: "ตั้งประกาศรับซื้อทุเรียนหน้าล้ง",
  },
  CUTTER: {
    title: "ผู้รับตัดทุเรียน (ทีมตัด)",
    shortTitle: "ทีมรับตัดทุเรียน",
    subtitle: "ประกาศคิวว่างรับจ้างตัดทุเรียน คัดเปอร์เซ็นต์แป้ง และรับงานจากสวน/ล้ง",
    badgeBg: "bg-amber-50 text-amber-700 border-amber-200",
    accentText: "text-amber-700",
    allowedPostType: "CUT_SERVICE",
    actionLabel: "ลงประกาศคิวว่างรับตัดทุเรียน",
  },
  ADMIN: {
    title: "ผู้ดูแลระบบ (Admin)",
    shortTitle: "Admin",
    subtitle: "ตรวจสอบเอกสารขอเพิ่มบทบาทที่ 2 และคัดกรองโพสต์ราคาผิดปกติ",
    badgeBg: "bg-purple-50 text-purple-700 border-purple-200",
    accentText: "text-purple-700",
    allowedPostType: "SELL",
    actionLabel: "จัดการระบบ",
  },
};

export default function DurianHubApp() {
  // ==========================================================================
  // 1. AUTHENTICATION STATE (หน้าแรกต้อง Login / สมัครสมาชิกก่อนเสมอ)
  // ==========================================================================
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [authTab, setAuthTab] = useState<"LOGIN" | "REGISTER">("LOGIN");
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccessMsg, setAuthSuccessMsg] = useState<string | null>(null);

  // Login / Register Form States
  const [loginEmailOrPhone, setLoginEmailOrPhone] = useState("seller@durian.com");
  const [loginPassword, setLoginPassword] = useState("password123");
  const [loginRoleSelect, setLoginRoleSelect] = useState<RoleType>("SELLER");

  const [regFullName, setRegFullName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regBusinessName, setRegBusinessName] = useState("");
  const [regProvince, setRegProvince] = useState("จันทบุรี");
  const [regPrimaryRole, setRegPrimaryRole] = useState<RoleType>("SELLER"); // บังคับเลือก 1 บทบาทตอนสมัคร

  // OTP Verification Modal States
  const [showOtpModal, setShowOtpModal] = useState<boolean>(false);
  const [otpUserId, setOtpUserId] = useState<number | null>(null);
  const [otpEmail, setOtpEmail] = useState<string>("");
  const [otpPurpose, setOtpPurpose] = useState<"VERIFY_EMAIL" | "RESET_PASSWORD">("VERIFY_EMAIL");
  const [otpCodeInput, setOtpCodeInput] = useState<string>("");
  const [otpError, setOtpError] = useState<string | null>(null);
  const [otpSuccess, setOtpSuccess] = useState<string | null>(null);
  const [isOtpLoading, setIsOtpLoading] = useState<boolean>(false);

  // Forgot Password Modal States
  const [showForgotModal, setShowForgotModal] = useState<boolean>(false);
  const [forgotEmail, setForgotEmail] = useState<string>("");
  const [forgotStep, setForgotStep] = useState<"EMAIL" | "OTP_NEW_PASSWORD">("EMAIL");
  const [forgotNewPassword, setForgotNewPassword] = useState<string>("");
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState<string>("");
  const [forgotError, setForgotError] = useState<string | null>(null);
  const [forgotSuccess, setForgotSuccess] = useState<string | null>(null);
  const [isForgotLoading, setIsForgotLoading] = useState<boolean>(false);

  // Logged-in User Profile State
  const [userProfile, setUserProfile] = useState<{
    id?: number;
    fullName: string;
    email?: string;
    phone: string;
    businessName: string;
    province: string;
    primaryRole: RoleType;
    approvedRoles: RoleType[];
    activeRole: RoleType;
    trustScore: number;
    rating: number;
    isEmailVerified?: boolean;
  }>({
    fullName: "คุณสมชาย ชาวสวนจันท์",
    phone: "089-456-7890",
    businessName: "สวนสมชาย จันทบุรี (GAP Certified)",
    province: "จันทบุรี",
    primaryRole: "SELLER",
    approvedRoles: ["SELLER"],
    activeRole: "SELLER",
    trustScore: 108,
    rating: 5.0,
  });

  // Chat Rooms State (อ้างอิงรูปที่ 5)
  const [chatRooms, setChatRooms] = useState<ChatRoomItem[]>([]);
  const [activeChatRoomId, setActiveChatRoomId] = useState<number>(0);
  const [chatInputText, setChatInputText] = useState<string>("");

  // Deal Modal & Negotiation State
  const [showCloseDealModal, setShowCloseDealModal] = useState<boolean>(false);
  const [dealAgreedPrice, setDealAgreedPrice] = useState<string>("");
  const [dealAgreedPricePerKg, setDealAgreedPricePerKg] = useState<string>("");
  const [dealAgreedQty, setDealAgreedQty] = useState<string>("");
  const [dealCutDate, setDealCutDate] = useState<string>("");
  const [dealNote, setDealNote] = useState<string>("");
  const [dealSuccessMsg, setDealSuccessMsg] = useState<string | null>(null);
  const [dealErrorMsg, setDealErrorMsg] = useState<string | null>(null);
  const [isDealLoading, setIsDealLoading] = useState<boolean>(false);

  // Check existing session on load
  useEffect(() => {
    async function checkSession() {
      try {
        const res = await fetch("/api/auth/me");
        if (res.ok) {
          const data = await res.json();
          if (data.authenticated && data.user) {
            setUserProfile(data.user);
            setIsAuthenticated(true);
          }
        }
      } catch (err) {
        console.error("Session check error:", err);
      }
    }
    checkSession();
  }, []);

  // Fetch real posts from API
  const fetchPosts = async () => {
    try {
      const res = await fetch("/api/posts");
      if (res.ok) {
        const data = await res.json();
        if (data.posts && data.posts.length > 0) {
          setPosts(data.posts);
        }
      }
    } catch (err) {
      console.error("fetch posts error", err);
    }
  };

  // Fetch chat rooms for current user
  const fetchChatRooms = async () => {
    try {
      const res = await fetch("/api/chat/rooms");
      if (res.ok) {
        const data = await res.json();
        if (data.rooms) {
          setChatRooms((prev) => {
            return data.rooms.map((newRoom: ChatRoomItem) => {
              const existing = prev.find((r) => r.id === newRoom.id);
              return {
                ...newRoom,
                messages:
                  newRoom.messages && newRoom.messages.length > 0
                    ? newRoom.messages
                    : existing?.messages || [],
              };
            });
          });
          if (
            data.rooms.length > 0 &&
            (!activeChatRoomId || !data.rooms.find((r: ChatRoomItem) => r.id === activeChatRoomId))
          ) {
            setActiveChatRoomId(data.rooms[0].id);
          }
        }
      }
    } catch (err) {
      console.error("fetch chat rooms error", err);
    }
  };

  // Fetch messages for active chat room
  const fetchMessages = async (roomId: number) => {
    try {
      const res = await fetch(`/api/chat/rooms/${roomId}/messages`);
      if (res.ok) {
        const data = await res.json();
        if (data.messages) {
          setChatRooms((prev) =>
            prev.map((r) => (r.id === roomId ? { ...r, messages: data.messages } : r))
          );
        }
      }
    } catch (err) {
      console.error("fetch messages error", err);
    }
  };

  // Real-time polling effect (every 2 seconds) when authenticated
  useEffect(() => {
    if (!isAuthenticated) return;
    fetchPosts();
    fetchChatRooms();

    const interval = setInterval(() => {
      fetchChatRooms();
      if (activeChatRoomId) {
        fetchMessages(activeChatRoomId);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [isAuthenticated, activeChatRoomId]);

  // When switching active chat room, fetch messages immediately
  useEffect(() => {
    if (activeChatRoomId && isAuthenticated) {
      fetchMessages(activeChatRoomId);
    }
  }, [activeChatRoomId, isAuthenticated]);

  // ==========================================================================
  // 2. MAIN NAVIGATION & VIEW STATE (หลังจาก Login สำเร็จ)
  // ==========================================================================
  const [currentView, setCurrentView] = useState<
    | "ROLE_HOME"
    | "REGIONAL_DASHBOARD"
    | "MARKETPLACE"
    | "POST_DETAIL"
    | "CHAT_ROOM"
  >("ROLE_HOME");

  // Regional Dashboard State (อ้างอิงรูปที่ 1)
  const [selectedRegionId, setSelectedRegionId] = useState<string>("EAST");

  // Marketplace State (อ้างอิงรูปที่ 2)
  const [posts, setPosts] = useState<MarketplacePostItem[]>(INITIAL_POSTS);
  const [selectedVarietyStrip, setSelectedVarietyStrip] =
    useState<string>("ALL");
  const [selectedRegionFilter, setSelectedRegionFilter] =
    useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showCreatePostModal, setShowCreatePostModal] =
    useState<boolean>(false);
  const [newPostType, setNewPostType] = useState<PostType>("SELL");

  const handleOpenCreatePostModal = (defaultType?: PostType) => {
    setNewPostType(defaultType || ROLE_CONFIG[userProfile.activeRole]?.allowedPostType || "SELL");
    if (selectedRegionFilter && selectedRegionFilter !== "ALL") {
      setNewPostRegion(selectedRegionFilter);
      const regObj = REGIONAL_SEASONS_DATA.find((r) => r.regionName === selectedRegionFilter);
      if (regObj && regObj.provinces.length > 0) {
        setNewPostProvince(regObj.provinces[0]);
      }
    }
    setShowCreatePostModal(true);
  };

  // Create Post Form State
  const [newPostTitle, setNewPostTitle] = useState("");
  const [newPostVariety, setNewPostVariety] = useState("หมอนทอง");
  const [newPostGrade, setNewPostGrade] = useState("AB ส่งออก");
  const [newPostProvince, setNewPostProvince] = useState("จันทบุรี");
  const [newPostRegion, setNewPostRegion] = useState("ภาคตะวันออก");
  const [newPostPrice, setNewPostPrice] = useState("172");
  const [newPostQty, setNewPostQty] = useState("5000");
  const [newPostContent, setNewPostContent] = useState("");
  const [postFeedback, setPostFeedback] = useState<string | null>(null);

  // Post Detail & Confirm Modal State (อ้างอิงรูปที่ 3 และ รูปที่ 4)
  const [selectedPost, setSelectedPost] = useState<MarketplacePostItem>(
    INITIAL_POSTS[0]
  );
  const [showChatConfirmModal, setShowChatConfirmModal] =
    useState<boolean>(false);
  const [copiedBanner, setCopiedBanner] = useState<boolean>(false);


  // Role Verification Request State (ขอเพิ่มบทบาทที่ 2 ด้วยเอกสาร)
  const [showRoleRequestModal, setShowRoleRequestModal] =
    useState<boolean>(false);
  const [roleRequests, setRoleRequests] = useState<RoleVerificationItem[]>(
    INITIAL_ROLE_REQUESTS
  );
  const [reqTargetRole, setReqTargetRole] = useState<RoleType>("CUTTER");
  const [reqBizName, setReqBizName] = useState("");
  const [reqLicenseNo, setReqLicenseNo] = useState("");
  const [reqDocType, setReqDocType] = useState(
    "ใบผ่านการอบรมนักตัดทุเรียน / ประวัติผลงาน"
  );
  const [reqDocFileName, setReqDocFileName] = useState(
    "เอกสารยืนยันตัวตนและใบรับรอง.pdf"
  );
  const [reqNote, setReqNote] = useState("");
  const [reqNotice, setReqNotice] = useState<string | null>(null);

  // ==========================================================================
  // HANDLERS
  // ==========================================================================

  // 1. Real Login Handler -> ยิง API /api/auth/login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);
    setIsAuthLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier: loginEmailOrPhone,
          password: loginPassword,
          roleSelect: loginRoleSelect,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.requireEmailVerification) {
          // อีเมลยังไม่ได้ยืนยัน -> เปิดหน้าต่างกรอก OTP ทันที
          setOtpUserId(data.userId);
          setOtpEmail(data.email);
          setOtpPurpose("VERIFY_EMAIL");
          setOtpError(data.error);
          setShowOtpModal(true);
          return;
        }
        setAuthError(data.error || "เกิดข้อผิดพลาดในการเข้าสู่ระบบ");
        return;
      }

      setUserProfile(data.user);
      setIsAuthenticated(true);
      setCurrentView("ROLE_HOME");
    } catch {
      setAuthError("ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setIsAuthLoading(false);
    }
  };

  // 2. Real Register Handler -> ยิง API /api/auth/register แล้วเปิดหน้าต่าง OTP
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);
    setIsAuthLoading(true);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: regFullName,
          email: regEmail,
          phone: regPhone,
          password: regPassword,
          businessName: regBusinessName,
          province: regProvince,
          primaryRole: regPrimaryRole,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setAuthError(data.error || "เกิดข้อผิดพลาดในการสมัครสมาชิก");
        return;
      }

      // สมัครสำเร็จ -> เปิด Modal ให้กรอก OTP 6 หลัก
      setOtpUserId(data.userId);
      setOtpEmail(data.email);
      setOtpPurpose("VERIFY_EMAIL");
      setOtpError(null);
      setOtpSuccess(data.message);
      setOtpCodeInput("");
      setShowOtpModal(true);
    } catch {
      setAuthError("ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setIsAuthLoading(false);
    }
  };

  // 3. Verify OTP Handler
  const handleVerifyOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpUserId) return;
    setOtpError(null);
    setOtpSuccess(null);
    setIsOtpLoading(true);

    try {
      const res = await fetch("/api/auth/verify-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: otpUserId,
          otpCode: otpCodeInput,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setOtpError(data.error || "รหัส OTP ไม่ถูกต้อง");
        return;
      }

      // ยืนยันสำเร็จ -> เข้าระบบอัตโนมัติ
      setUserProfile(data.user);
      setShowOtpModal(false);
      setIsAuthenticated(true);
      setCurrentView("ROLE_HOME");
    } catch {
      setOtpError("เกิดข้อผิดพลาดในการเชื่อมต่อ กรุณาลองใหม่");
    } finally {
      setIsOtpLoading(false);
    }
  };

  // 4. Resend OTP Handler
  const handleResendOtp = async () => {
    if (!otpUserId) return;
    setOtpError(null);
    setOtpSuccess(null);
    setIsOtpLoading(true);

    try {
      const res = await fetch("/api/auth/resend-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: otpUserId,
          purpose: otpPurpose,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setOtpError(data.error || "ไม่สามารถส่งรหัสใหม่ได้");
      } else {
        setOtpSuccess(data.message || "ส่งรหัสใหม่ไปยังกล่องอีเมลแล้ว");
      }
    } catch {
      setOtpError("เกิดข้อผิดพลาดในการส่งรหัสใหม่");
    } finally {
      setIsOtpLoading(false);
    }
  };

  // 5. Forgot Password: Step 1 (Request OTP via Email)
  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotSuccess(null);
    setIsForgotLoading(true);

    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: forgotEmail }),
      });

      const data = await res.json();
      if (!res.ok) {
        setForgotError(data.error || "เกิดข้อผิดพลาด");
        return;
      }

      if (data.userId) {
        setOtpUserId(data.userId);
        setOtpEmail(data.email);
        setForgotStep("OTP_NEW_PASSWORD");
        setForgotSuccess(data.message);
      } else {
        setForgotSuccess(data.message);
      }
    } catch {
      setForgotError("เกิดข้อผิดพลาดในการเชื่อมต่อ");
    } finally {
      setIsForgotLoading(false);
    }
  };

  // 6. Reset Password: Step 2 (Submit OTP + New Password)
  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (forgotNewPassword !== forgotConfirmPassword) {
      setForgotError("รหัสผ่านใหม่และการยืนยันรหัสผ่านไม่ตรงกัน");
      return;
    }
    setForgotError(null);
    setForgotSuccess(null);
    setIsForgotLoading(true);

    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: otpUserId,
          otpCode: otpCodeInput,
          newPassword: forgotNewPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setForgotError(data.error || "ไม่สามารถเปลี่ยนรหัสผ่านได้");
        return;
      }

      // สำเร็จ ปิดหน้าต่างแล้วแจ้งให้ล็อกอินใหม่
      setShowForgotModal(false);
      setForgotStep("EMAIL");
      setForgotEmail("");
      setForgotNewPassword("");
      setForgotConfirmPassword("");
      setOtpCodeInput("");
      setAuthSuccessMsg("ตั้งรหัสผ่านใหม่เรียบร้อยแล้ว กรุณาเข้าสู่ระบบด้วยรหัสผ่านใหม่");
      setAuthTab("LOGIN");
    } catch {
      setForgotError("เกิดข้อผิดพลาดในการเชื่อมต่อ");
    } finally {
      setIsForgotLoading(false);
    }
  };

  // 7. Logout Handler
  const handleLogoutSubmit = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch (err) {
      console.error(err);
    }
    setIsAuthenticated(false);
  };

  // 3. Open Post Detail (รูปที่ 3)
  const handleOpenPostDetail = (post: MarketplacePostItem) => {
    setSelectedPost(post);
    setCurrentView("POST_DETAIL");
  };

  // 4. Confirm Chat from Modal -> POST /api/chat/rooms
  const handleConfirmStartChat = async () => {
    setShowChatConfirmModal(false);
    try {
      const res = await fetch("/api/chat/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ postId: selectedPost.id }),
      });
      const data = await res.json();
      if (res.ok && data.roomId) {
        await fetchChatRooms();
        await fetchMessages(data.roomId);
        setActiveChatRoomId(data.roomId);
      } else {
        alert(data.error || "ไม่สามารถเปิดห้องแชทได้");
      }
    } catch (err) {
      console.error("Chat start error:", err);
    }
    setCurrentView("CHAT_ROOM");
  };

  // 5. Send Chat Message or Quick Reply Chip -> POST /api/chat/rooms/[id]/messages
  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || !activeChatRoomId) return;
    const currentRoomId = activeChatRoomId;
    setChatInputText("");

    try {
      const res = await fetch(`/api/chat/rooms/${currentRoomId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: textToSend }),
      });
      if (res.ok) {
        await fetchMessages(currentRoomId);
        fetchChatRooms();
      }
    } catch (err) {
      console.error("send message error:", err);
    }
  };

  // 6. Close Deal Handler -> POST /api/deals
  const handleCloseDeal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeChatRoom) return;
    setIsDealLoading(true);
    setDealErrorMsg(null);
    setDealSuccessMsg(null);

    const priceNum = parseFloat(dealAgreedPrice) || 0;
    const pricePerKgNum = parseFloat(dealAgreedPricePerKg) || 0;
    const qtyNum = parseFloat(dealAgreedQty) || 0;

    try {
      const res = await fetch("/api/deals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          roomId: activeChatRoom.id,
          postId: activeChatRoom.post?.id,
          receiverId: (activeChatRoom as any).partnerId,
          agreedPrice: priceNum || (pricePerKgNum * qtyNum),
          agreedPricePerKg: pricePerKgNum || (qtyNum > 0 ? priceNum / qtyNum : priceNum),
          agreedQuantityKg: qtyNum || null,
          cutDate: dealCutDate || null,
          note: dealNote || null,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setDealErrorMsg(data.error || "ไม่สามารถทำรายการปิดดีลได้");
        return;
      }

      setDealSuccessMsg("🎉 ตกลงราคาซื้อขายและบันทึกสัญญาดีลสำเร็จแล้ว!");
      await fetchMessages(activeChatRoom.id);
      await fetchChatRooms();
      setTimeout(() => {
        setShowCloseDealModal(false);
        setDealSuccessMsg(null);
        setDealAgreedPrice("");
        setDealAgreedPricePerKg("");
        setDealAgreedQty("");
        setDealCutDate("");
        setDealNote("");
      }, 1500);
    } catch {
      setDealErrorMsg("เกิดข้อผิดพลาดในการเชื่อมต่อ");
    } finally {
      setIsDealLoading(false);
    }
  };

  // 7. Create New Marketplace Post -> POST /api/posts
  const handleCreateNewPost = async (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(newPostPrice) || 0;
    const qtyNum = parseFloat(newPostQty) || 0;
    const postType = newPostType || ROLE_CONFIG[userProfile.activeRole].allowedPostType;

    // Outlier validation (+/- 30% from reference price)
    const refItem = VARIETY_STRIP_ITEMS.find((v) => v.id === newPostVariety);
    const refPrice = refItem ? refItem.avgPrice : 170;
    const isOutlier =
      postType !== "CUT_SERVICE" &&
      (priceNum > refPrice * 1.3 || priceNum < refPrice * 0.7);

    try {
      const res = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newPostTitle || `${newPostVariety} เกรด ${newPostGrade} (${(qtyNum / 1000).toFixed(1)} ตัน)`,
          content: newPostContent || `ประกาศโดย ${userProfile.businessName} พื้นที่ จ.${newPostProvince} (${newPostRegion})`,
          postType,
          varietyName: newPostVariety,
          gradeCode: newPostGrade,
          province: newPostProvince,
          region: newPostRegion,
          price: priceNum,
          pricePerKg: priceNum,
          quantityKg: qtyNum,
          dryMatterPct: 34.0,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "ไม่สามารถลงประกาศได้");
        return;
      }

      await fetchPosts();
      setShowCreatePostModal(false);
      setNewPostTitle("");
      setNewPostContent("");
      const catLabel =
        postType === "SELL"
          ? "โพสต์ขายทุเรียน (Sell Orders)"
          : postType === "BUY"
          ? "โพสต์รับซื้อหน้าล้ง (Buy Orders)"
          : "โพสต์รับตัดทุเรียน (Cut Service)";
      setPostFeedback(
        isOutlier
          ? `⚠️ โพสต์ของคุณถูกบันทึกในหมวด "${catLabel}" แล้ว แต่เนื่องจากราคา (${priceNum} บ.) สูงหรือต่ำกว่าราคากลางเกิน ±30% ระบบจึงไม่นำไปคำนวณในกราฟราคากลางเพื่อป้องกันการปั่นราคา`
          : `✅ ลงประกาศในหมวด "${catLabel}" สำเร็จแล้ว!`
      );
    } catch (err) {
      console.error("create post error:", err);
    }
  };

  // 7. Submit 2nd Role Verification Request
  const handleSubmitExtraRoleRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (userProfile.approvedRoles.includes(reqTargetRole)) {
      setReqNotice("คุณได้รับอนุมัติบทบาทนี้แล้ว สามารถสลับบทบาทที่แถบด้านบนได้เลย");
      return;
    }
    const newReq: RoleVerificationItem = {
      id: Date.now(),
      userName: userProfile.fullName,
      currentPrimaryRole: userProfile.primaryRole,
      requestedRole: reqTargetRole,
      businessName: reqBizName || `${userProfile.businessName} (บทบาทที่ 2)`,
      licenseNumber: reqLicenseNo || "DOC-2569-991",
      documentType: reqDocType,
      documentName: reqDocFileName,
      note: reqNote || "ขอยื่นเอกสารเพื่อเปิดใช้งานบทบาทที่ 2",
      status: "PENDING",
      createdAt: "เมื่อสักครู่",
    };
    setRoleRequests([newReq, ...roleRequests]);
    setReqNotice(
      `ส่งเอกสารขอเพิ่มบทบาท "${ROLE_CONFIG[reqTargetRole].shortTitle}" สำเร็จ! (คุณสามารถกดปุ่มจำลอง Admin อนุมัติได้ด้านล่างเพื่อทดสอบสลับบทบาท)`
    );
  };

  const handleApproveRoleRequest = (req: RoleVerificationItem) => {
    setRoleRequests((prev) =>
      prev.map((r) => (r.id === req.id ? { ...r, status: "APPROVED" } : r))
    );
    if (!userProfile.approvedRoles.includes(req.requestedRole)) {
      setUserProfile((prev) => ({
        ...prev,
        approvedRoles: [...prev.approvedRoles, req.requestedRole],
      }));
    }
  };

  // Filtered Posts for Marketplace 3 Columns
  const filteredMarketplacePosts = useMemo(() => {
    return posts.filter((p) => {
      if (
        selectedVarietyStrip !== "ALL" &&
        p.variety !== selectedVarietyStrip
      ) {
        return false;
      }
      const postRegion = p.regionTag || (p as any).region || "";
      if (
        selectedRegionFilter !== "ALL" &&
        postRegion !== selectedRegionFilter
      ) {
        return false;
      }
      if (
        searchQuery.trim() !== "" &&
        !p.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !p.province.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !p.authorName.toLowerCase().includes(searchQuery.toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [posts, selectedVarietyStrip, selectedRegionFilter, searchQuery]);

  const sellOrders = filteredMarketplacePosts.filter(
    (p) => p.postType === "SELL"
  );
  const buyOrders = filteredMarketplacePosts.filter(
    (p) => p.postType === "BUY"
  );
  const cutOrders = filteredMarketplacePosts.filter(
    (p) => p.postType === "CUT_SERVICE"
  );

  // Dynamic Regional Dashboard Data calculated from live posts in DB
  const computedRegionalSeasonsData = useMemo(() => {
    return REGIONAL_SEASONS_DATA.map((reg) => {
      // Find all posts in this region (by regionTag, region, or province matching)
      const regionPosts = posts.filter((p) => {
        const pReg = p.regionTag || (p as any).region || "";
        return (
          pReg === reg.regionName ||
          reg.provinces.some((prov) => p.province && p.province.includes(prov))
        );
      });

      const sellPosts = regionPosts.filter((p) => p.postType === "SELL");
      const buyPosts = regionPosts.filter((p) => p.postType === "BUY");
      const cutPosts = regionPosts.filter((p) => p.postType === "CUT_SERVICE");

      // Dynamic average sell price
      let dynamicAvgSell = reg.avgSellPrice;
      if (sellPosts.length > 0) {
        const total = sellPosts.reduce(
          (acc, cur) => acc + (cur.pricePerKg || 0),
          0
        );
        dynamicAvgSell = Math.round((total / sellPosts.length) * 10) / 10;
      }

      // Dynamic average buy price
      let dynamicAvgBuy = reg.avgBuyPrice;
      if (buyPosts.length > 0) {
        const total = buyPosts.reduce(
          (acc, cur) => acc + (cur.pricePerKg || 0),
          0
        );
        dynamicAvgBuy = Math.round((total / buyPosts.length) * 10) / 10;
      }

      // Dynamic average cut wage
      let dynamicAvgCut = reg.avgCutWage;
      if (cutPosts.length > 0) {
        const total = cutPosts.reduce(
          (acc, cur) => acc + (cur.pricePerKg || 0),
          0
        );
        dynamicAvgCut = Math.round((total / cutPosts.length) * 10) / 10;
      }

      // Dynamic price by variety breakdown
      const dynamicPriceByVariety = reg.priceByVariety.map((pv) => {
        const vSellPosts = sellPosts.filter(
          (p) => p.variety && p.variety.includes(pv.variety)
        );
        const vBuyPosts = buyPosts.filter(
          (p) => p.variety && p.variety.includes(pv.variety)
        );

        let vSellPrice = pv.sellPrice;
        if (vSellPosts.length > 0) {
          const total = vSellPosts.reduce(
            (acc, cur) => acc + (cur.pricePerKg || 0),
            0
          );
          vSellPrice = Math.round(total / vSellPosts.length);
        }

        let vBuyPrice = pv.buyPrice;
        if (vBuyPosts.length > 0) {
          const total = vBuyPosts.reduce(
            (acc, cur) => acc + (cur.pricePerKg || 0),
            0
          );
          vBuyPrice = Math.round(total / vBuyPosts.length);
        }

        return {
          ...pv,
          sellPrice: vSellPrice,
          buyPrice: vBuyPrice,
        };
      });

      return {
        ...reg,
        avgSellPrice: dynamicAvgSell,
        avgBuyPrice: dynamicAvgBuy,
        avgCutWage: dynamicAvgCut,
        activeLotsCount:
          regionPosts.length > 0 ? regionPosts.length : reg.activeLotsCount,
        hasLivePosts: regionPosts.length > 0,
        livePostsCount: regionPosts.length,
        priceByVariety: dynamicPriceByVariety,
      };
    });
  }, [posts]);

  const selectedRegionalData =
    computedRegionalSeasonsData.find((r) => r.id === selectedRegionId) ||
    computedRegionalSeasonsData[0];

  const activeChatRoom =
    chatRooms.find((r) => r.id === activeChatRoomId) || chatRooms[0];

  // ==========================================================================
  // VIEW 0: AUTHENTICATION GATE (หน้าแรกบังคับให้ Login หรือ สมัครสมาชิกก่อน)
  // ==========================================================================
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-emerald-50/40 to-teal-50/30 flex items-center justify-center p-4 sm:p-6">
        <div className="max-w-5xl w-full bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          {/* Left Branding Panel */}
          <div className="lg:col-span-5 bg-gradient-to-br from-emerald-800 via-emerald-900 to-teal-950 text-white p-8 sm:p-10 flex flex-col justify-between">
            <div>
              <div className="inline-flex items-center gap-2.5 bg-white/10 backdrop-blur px-3.5 py-1.5 rounded-full text-xs font-medium text-emerald-100 border border-white/15">
                <Sprout className="w-4 h-4 text-lime-300" />
                Thailand Durian Marketplace
              </div>
              <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-5 leading-tight">
                Durian Hub
              </h1>
              <p className="text-emerald-100/90 text-sm mt-3 leading-relaxed">
                แพลตฟอร์มตลาดกลางทุเรียนไทยครบวงจร เชื่อมโยงชาวสวนผู้ขาย ล้งรับซื้อ
                และทีมรับตัดทุเรียน พร้อมแดชบอร์ดราคากลางและฤดูกาลทุเรียนทั้ง 6 ภูมิภาค
              </p>

              <div className="mt-8 space-y-3.5 text-xs text-emerald-100">
                <div className="flex items-start gap-3 bg-white/5 p-3.5 rounded-2xl border border-white/10">
                  <ShieldCheck className="w-5 h-5 text-lime-300 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">
                      ระบบแยกบทบาทชัดเจน (Role-Based System)
                    </div>
                    <p className="text-emerald-200/80 mt-0.5">
                      ตอนสมัครเลือกได้ 1 บทบาทหลัก หากต้องการเพิ่มบทบาทที่ 2 ต้องส่งเอกสารคัดกรองเพื่อป้องกันการปั่นราคา
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-white/5 p-3.5 rounded-2xl border border-white/10">
                  <BarChart3 className="w-5 h-5 text-lime-300 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">
                      แดชบอร์ดราคาและฤดูกาลทุเรียนรายพื้นที่
                    </div>
                    <p className="text-emerald-200/80 mt-0.5">
                      เช็กช่วงเดือนทุเรียนสุกและเปรียบเทียบราคารับซื้อ-ขายจริงในแต่ละภูมิภาค
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-white/10 text-xs text-emerald-200/70 flex items-center justify-between">
              <span>© 2026 Durian Hub Thailand</span>
              <span>Clean & Modern UI</span>
            </div>
          </div>

          {/* Right Form Panel (Login / Register) */}
          <div className="lg:col-span-7 p-8 sm:p-10 flex flex-col justify-center">
            {/* Switch Tabs */}
            <div className="flex bg-slate-100 p-1 rounded-2xl mb-6 w-fit">
              <button
                type="button"
                onClick={() => setAuthTab("LOGIN")}
                className={`px-6 py-2.5 rounded-xl text-sm font-bold transition ${
                  authTab === "LOGIN"
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                เข้าสู่ระบบ (Login)
              </button>
              <button
                type="button"
                onClick={() => setAuthTab("REGISTER")}
                className={`px-6 py-2.5 rounded-xl text-sm font-bold transition ${
                  authTab === "REGISTER"
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                สมัครสมาชิกใหม่ (เลือก 1 บทบาท)
              </button>
            </div>

            {/* Alert Messages */}
            {authError && (
              <div className="mb-5 p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2.5">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
                <span>{authError}</span>
              </div>
            )}
            {authSuccessMsg && (
              <div className="mb-5 p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{authSuccessMsg}</span>
              </div>
            )}

            {authTab === "LOGIN" ? (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900">
                    ยินดีต้อนรับเข้าสู่ Durian Hub
                  </h2>
                  <p className="text-sm text-slate-500 mt-1">
                    กรุณาเข้าสู่ระบบด้วยอีเมลหรือเบอร์โทรศัพท์ของคุณ
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    อีเมล หรือ เบอร์โทรศัพท์
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="เช่น seller@durian.com หรือ 089-456-7890"
                    value={loginEmailOrPhone}
                    onChange={(e) => setLoginEmailOrPhone(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/50 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700">
                      รหัสผ่าน
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setForgotEmail(loginEmailOrPhone.includes("@") ? loginEmailOrPhone : "");
                        setForgotStep("EMAIL");
                        setForgotError(null);
                        setForgotSuccess(null);
                        setShowForgotModal(true);
                      }}
                      className="text-xs font-medium text-emerald-700 hover:text-emerald-800 hover:underline"
                    >
                      ลืมรหัสผ่าน?
                    </button>
                  </div>
                  <input
                    type="password"
                    required
                    placeholder="กรอกรหัสผ่านของคุณ"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/50 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-2">
                    เลือกบทบาทที่ต้องการเข้าใช้งาน:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {(["SELLER", "BUYER", "CUTTER"] as RoleType[]).map((r) => (
                      <button
                        type="button"
                        key={r}
                        onClick={() => {
                          setLoginRoleSelect(r);
                          if (r === "SELLER") {
                            setLoginEmailOrPhone("seller@durian.com");
                            setLoginPassword("password123");
                          } else if (r === "BUYER") {
                            setLoginEmailOrPhone("buyer@durian.com");
                            setLoginPassword("password123");
                          } else if (r === "CUTTER") {
                            setLoginEmailOrPhone("cutter@durian.com");
                            setLoginPassword("password123");
                          }
                        }}
                        className={`p-3 rounded-2xl border text-left transition ${
                          loginRoleSelect === r
                            ? "border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-500/20"
                            : "border-slate-200 hover:border-slate-300 bg-white"
                        }`}
                      >
                        <div className="text-xs font-bold text-slate-900">
                          {ROLE_CONFIG[r].shortTitle}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                          {ROLE_CONFIG[r].actionLabel}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isAuthLoading}
                  className="w-full bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold py-3 px-6 rounded-2xl transition shadow-sm flex items-center justify-center gap-2"
                >
                  {isAuthLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      เข้าสู่ระบบไปยังหน้า{ROLE_CONFIG[loginRoleSelect].shortTitle}
                      <ChevronRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
                  <span>💡 บัญชีทดสอบที่ Seed ไว้: รหัสผ่าน <strong>password123</strong></span>
                  <a
                    href="http://localhost:8025"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 font-semibold text-emerald-700 hover:underline"
                  >
                    กล่องจดหมาย Mailpit <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </form>
            ) : (
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">
                    สมัครสมาชิกใหม่ (บังคับกรอกอีเมลเพื่อรับ OTP)
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    ระบบจะจัดส่งรหัส OTP 6 หลักไปยังอีเมลเพื่อยืนยันตัวตนก่อนเริ่มใช้งาน
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ชื่อ-นามสกุล
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="เช่น นายสมศักดิ์ รักสวนจันท์"
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      อีเมล (สำหรับรับรหัส OTP) *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="เช่น yourname@durian.com"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-emerald-300 bg-emerald-50/20 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      เบอร์โทรศัพท์
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="08X-XXX-XXXX"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ชื่อสวน / ชื่อล้ง / ชื่อทีมตัด
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="ระบุชื่อกิจการของคุณ"
                      value={regBusinessName}
                      onChange={(e) => setRegBusinessName(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      จังหวัดหลักที่ตั้ง
                    </label>
                    <select
                      value={regProvince}
                      onChange={(e) => setRegProvince(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="จันทบุรี">จันทบุรี (ภาคตะวันออก)</option>
                      <option value="ระยอง">ระยอง (ภาคตะวันออก)</option>
                      <option value="ตราด">ตราด (ภาคตะวันออก)</option>
                      <option value="ชุมพร">ชุมพร (ภาคใต้)</option>
                      <option value="ศรีสะเกษ">ศรีสะเกษ (ภาคอีสาน)</option>
                      <option value="อุตรดิตถ์">อุตรดิตถ์ (ภาคเหนือ)</option>
                      <option value="นนทบุรี">นนทบุรี (ภาคกลาง)</option>
                      <option value="ยะลา">ยะลา (3 จังหวัดชายแดนใต้)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ตั้งรหัสผ่าน
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="อย่างน้อย 6 ตัวอักษร"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    เลือก Member Role หลักของคุณ (เลือกได้ 1 บทบาท):
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {(["SELLER", "BUYER", "CUTTER"] as RoleType[]).map((r) => (
                      <label
                        key={r}
                        className={`p-3 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                          regPrimaryRole === r
                            ? "border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-500/20"
                            : "border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="regRole"
                            checked={regPrimaryRole === r}
                            onChange={() => setRegPrimaryRole(r)}
                            className="text-emerald-600"
                          />
                          <span className="text-xs font-bold text-slate-900">
                            {ROLE_CONFIG[r].shortTitle}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          {ROLE_CONFIG[r].actionLabel}
                        </p>
                      </label>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isAuthLoading}
                  className="w-full bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold py-3 px-6 rounded-2xl transition shadow-sm flex items-center justify-center gap-2"
                >
                  {isAuthLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      สมัครสมาชิกและรับรหัส OTP ทางอีเมล
                      <ChevronRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* ================================================================== */}
        {/* MODAL 1: OTP VERIFICATION DIALOG */}
        {/* ================================================================== */}
        {showOtpModal && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-100 relative animate-in fade-in zoom-in-95 duration-200">
              <button
                onClick={() => setShowOtpModal(false)}
                className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 p-1.5 rounded-full hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-center">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-4 shadow-inner">
                  <Mail className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-900">
                  ยืนยันรหัส OTP ทางอีเมล
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  ระบบได้ส่งรหัส OTP 6 หลักไปยังอีเมล:
                  <br />
                  <strong className="text-emerald-700 font-semibold">{otpEmail}</strong>
                </p>
              </div>

              {/* Status Alerts */}
              {otpError && (
                <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
                  <span>{otpError}</span>
                </div>
              )}
              {otpSuccess && (
                <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>{otpSuccess}</span>
                </div>
              )}

              {/* Direct Mailpit Link for Testing */}
              <div className="mt-4 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
                <span>📬 ดูอีเมลจำลองในเครื่อง:</span>
                <a
                  href="http://localhost:8025"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200"
                >
                  เปิด Mailpit (8025) <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <form onSubmit={handleVerifyOtpSubmit} className="mt-5 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5 text-center">
                    กรอกรหัส OTP 6 หลัก
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    placeholder="• • • • • •"
                    value={otpCodeInput}
                    onChange={(e) => setOtpCodeInput(e.target.value.replace(/\D/g, ""))}
                    className="w-full text-center text-3xl font-extrabold tracking-widest py-3 rounded-2xl border-2 border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-500 focus:outline-none"
                    autoFocus
                  />
                  <div className="text-[11px] text-slate-400 text-center mt-1">
                    รหัสมีอายุการใช้งาน 10 นาที
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isOtpLoading || otpCodeInput.length !== 6}
                  className="w-full bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40 text-white font-bold py-3 rounded-2xl transition shadow-sm flex items-center justify-center gap-2"
                >
                  {isOtpLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    "ยืนยันและเข้าสู่ระบบทันที"
                  )}
                </button>
              </form>

              <div className="mt-4 text-center">
                <button
                  type="button"
                  disabled={isOtpLoading}
                  onClick={handleResendOtp}
                  className="text-xs text-slate-500 hover:text-emerald-700 font-semibold transition"
                >
                  ไม่ได้รับรหัส? ขอรหัส OTP ใหม่อีกครั้ง
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================================================================== */}
        {/* MODAL 2: FORGOT PASSWORD DIALOG */}
        {/* ================================================================== */}
        {showForgotModal && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-100 relative animate-in fade-in zoom-in-95 duration-200">
              <button
                onClick={() => setShowForgotModal(false)}
                className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 p-1.5 rounded-full hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-center">
                <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto mb-4 shadow-inner">
                  <KeyRound className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-900">
                  ลืมรหัสผ่าน (Reset Password)
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  {forgotStep === "EMAIL"
                    ? "กรอกอีเมลของคุณเพื่อรับรหัส OTP สำหรับตั้งรหัสผ่านใหม่"
                    : `กรอกรหัส OTP ที่ได้รับทางอีเมล ${otpEmail} และตั้งรหัสผ่านใหม่`}
                </p>
              </div>

              {/* Status Alerts */}
              {forgotError && (
                <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
                  <span>{forgotError}</span>
                </div>
              )}
              {forgotSuccess && (
                <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>{forgotSuccess}</span>
                </div>
              )}

              {/* Mailpit Link */}
              <div className="mt-4 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
                <span>📬 ดูอีเมลจำลองในเครื่อง:</span>
                <a
                  href="http://localhost:8025"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200"
                >
                  เปิด Mailpit (8025) <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              {forgotStep === "EMAIL" ? (
                <form onSubmit={handleForgotPasswordSubmit} className="mt-5 space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      อีเมลที่ลงทะเบียนไว้
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="เช่น seller@durian.com"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isForgotLoading}
                    className="w-full bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold py-3 rounded-2xl transition shadow-sm flex items-center justify-center gap-2"
                  >
                    {isForgotLoading ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      "ส่งรหัส OTP ไปยังอีเมล"
                    )}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleResetPasswordSubmit} className="mt-5 space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      รหัส OTP 6 หลัก
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      placeholder="• • • • • •"
                      value={otpCodeInput}
                      onChange={(e) => setOtpCodeInput(e.target.value.replace(/\D/g, ""))}
                      className="w-full text-center text-2xl font-bold tracking-widest py-2.5 rounded-xl border-2 border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ตั้งรหัสผ่านใหม่
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="อย่างน้อย 6 ตัวอักษร"
                      value={forgotNewPassword}
                      onChange={(e) => setForgotNewPassword(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ยืนยันรหัสผ่านใหม่อีกครั้ง
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="กรอกรหัสผ่านใหม่อีกครั้ง"
                      value={forgotConfirmPassword}
                      onChange={(e) => setForgotConfirmPassword(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isForgotLoading || otpCodeInput.length !== 6}
                    className="w-full bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold py-3 rounded-2xl transition shadow-sm flex items-center justify-center gap-2 mt-2"
                  >
                    {isForgotLoading ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      "บันทึกรหัสผ่านใหม่"
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================================================
  // AUTHENTICATED LAYOUT (Modern Clean Minimal Navbar + Role Workspace)
  // ==========================================================================
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col">
      {/* Top Clean Modern Navbar */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-6">
            <button
              onClick={() => setCurrentView("ROLE_HOME")}
              className="flex items-center gap-2.5 text-left"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-extrabold text-lg shadow-sm">
                D
              </div>
              <div>
                <div className="font-bold text-slate-900 text-base leading-none">
                  DURIAN HUB
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  THAILAND MARKETPLACE
                </div>
              </div>
            </button>

            {/* Primary Navigation Links */}
            <nav className="hidden md:flex items-center gap-1">
              <button
                onClick={() => setCurrentView("ROLE_HOME")}
                className={`px-3.5 py-2 rounded-xl text-sm font-medium transition ${
                  currentView === "ROLE_HOME"
                    ? "bg-emerald-50 text-emerald-800 font-bold"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                }`}
              >
                หน้าบทบาทของคุณ ({ROLE_CONFIG[userProfile.activeRole].shortTitle})
              </button>

              <button
                onClick={() => setCurrentView("REGIONAL_DASHBOARD")}
                className={`px-3.5 py-2 rounded-xl text-sm font-medium transition ${
                  currentView === "REGIONAL_DASHBOARD"
                    ? "bg-emerald-50 text-emerald-800 font-bold"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                }`}
              >
                แดชบอร์ดทุเรียนรายพื้นที่
              </button>

              <button
                onClick={() => setCurrentView("MARKETPLACE")}
                className={`px-3.5 py-2 rounded-xl text-sm font-medium transition ${
                  currentView === "MARKETPLACE" || currentView === "POST_DETAIL"
                    ? "bg-emerald-50 text-emerald-800 font-bold"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                }`}
              >
                ตลาดกลางซื้อ-ขาย-รับตัด
              </button>

              <button
                onClick={() => setCurrentView("CHAT_ROOM")}
                className={`px-3.5 py-2 rounded-xl text-sm font-medium transition flex items-center gap-1.5 ${
                  currentView === "CHAT_ROOM"
                    ? "bg-emerald-50 text-emerald-800 font-bold"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                ห้องแชท ({chatRooms.length})
              </button>
            </nav>
          </div>

          {/* Right User Role Status & Switcher */}
          <div className="flex items-center gap-2.5">
            <div className="hidden sm:flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200/80">
              <span className="text-xs text-slate-500">บทบาท:</span>
              <select
                value={userProfile.activeRole}
                onChange={(e) =>
                  setUserProfile({
                    ...userProfile,
                    activeRole: e.target.value as RoleType,
                  })
                }
                className="text-xs font-bold text-emerald-800 bg-transparent focus:outline-none cursor-pointer"
              >
                {userProfile.approvedRoles.map((r) => (
                  <option key={r} value={r}>
                    {ROLE_CONFIG[r].shortTitle}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => setShowRoleRequestModal(true)}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-emerald-200 bg-emerald-50/70 text-emerald-800 hover:bg-emerald-100 transition"
            >
              + ขอเพิ่มบทบาทที่ 2
            </button>

            <button
              onClick={handleLogoutSubmit}
              title="ออกจากระบบ"
              className="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="md:hidden flex overflow-x-auto border-t border-slate-100 px-4 py-2 gap-2 bg-white">
          <button
            onClick={() => setCurrentView("ROLE_HOME")}
            className={`text-xs px-3 py-1.5 rounded-lg whitespace-nowrap font-semibold ${
              currentView === "ROLE_HOME"
                ? "bg-emerald-700 text-white"
                : "bg-slate-100 text-slate-600"
            }`}
          >
            หน้าบทบาท
          </button>
          <button
            onClick={() => setCurrentView("REGIONAL_DASHBOARD")}
            className={`text-xs px-3 py-1.5 rounded-lg whitespace-nowrap font-semibold ${
              currentView === "REGIONAL_DASHBOARD"
                ? "bg-emerald-700 text-white"
                : "bg-slate-100 text-slate-600"
            }`}
          >
            แดชบอร์ดรายพื้นที่
          </button>
          <button
            onClick={() => setCurrentView("MARKETPLACE")}
            className={`text-xs px-3 py-1.5 rounded-lg whitespace-nowrap font-semibold ${
              currentView === "MARKETPLACE"
                ? "bg-emerald-700 text-white"
                : "bg-slate-100 text-slate-600"
            }`}
          >
            ตลาดกลาง
          </button>
          <button
            onClick={() => setCurrentView("CHAT_ROOM")}
            className={`text-xs px-3 py-1.5 rounded-lg whitespace-nowrap font-semibold ${
              currentView === "CHAT_ROOM"
                ? "bg-emerald-700 text-white"
                : "bg-slate-100 text-slate-600"
            }`}
          >
            แชท ({chatRooms.length})
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {postFeedback && (
          <div className="mb-5 p-4 rounded-2xl bg-white border border-emerald-200 shadow-sm flex items-center justify-between gap-3 text-sm text-slate-800">
            <span>{postFeedback}</span>
            <button
              onClick={() => setPostFeedback(null)}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              ปิด
            </button>
          </div>
        )}

        {/* ===================================================================
            VIEW 1: ROLE WORKSPACE (เมื่อล็อกอินสำเร็จ จะเข้ามายังบทบาทที่สมัคร)
           =================================================================== */}
        {currentView === "ROLE_HOME" && (
          <div className="space-y-6">
            {/* Welcome Role Banner */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full border ${
                      ROLE_CONFIG[userProfile.activeRole].badgeBg
                    }`}
                  >
                    บทบาทปัจจุบัน: {ROLE_CONFIG[userProfile.activeRole].title}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5" /> ยืนยันตัวตนแล้ว • เครดิต{" "}
                    {userProfile.trustScore}
                  </span>
                </div>

                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                  สวัสดีครับ, {userProfile.fullName} ({userProfile.businessName})
                </h1>
                <p className="text-sm text-slate-500 max-w-2xl">
                  {ROLE_CONFIG[userProfile.activeRole].subtitle} • พื้นที่หลักของคุณ:{" "}
                  <strong className="text-slate-700">จ.{userProfile.province}</strong>
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => handleOpenCreatePostModal()}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm px-5 py-3 rounded-2xl shadow-sm transition flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  {ROLE_CONFIG[userProfile.activeRole].actionLabel}
                </button>
                <button
                  onClick={() => setCurrentView("MARKETPLACE")}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-sm px-5 py-3 rounded-2xl transition"
                >
                  ไปที่ตลาดกลางซื้อขาย
                </button>
              </div>
            </div>

            {/* 3 Quick Action Cards Tailored to User's Role */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div
                onClick={() => setCurrentView("REGIONAL_DASHBOARD")}
                className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm hover:border-emerald-400 transition cursor-pointer group"
              >
                <div className="w-11 h-11 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-4 group-hover:bg-emerald-700 group-hover:text-white transition">
                  <MapPin className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base text-slate-900">
                  1. แดชบอร์ดทุเรียนแต่ละพื้นที่ & ฤดูกาลสุก
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  ดูแผนที่ทุเรียนไทยทั้ง 6 ภูมิภาค ช่วงเดือนผลผลิตออก สายพันธุ์เด่น และกราฟเปรียบเทียบราคากลางแต่ละจังหวัด
                </p>
                <div className="mt-4 text-xs font-bold text-emerald-700 flex items-center gap-1">
                  เปิดดูแดชบอร์ดรายพื้นที่ <ChevronRight className="w-4 h-4" />
                </div>
              </div>

              <div
                onClick={() => setCurrentView("MARKETPLACE")}
                className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm hover:border-emerald-400 transition cursor-pointer group"
              >
                <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-700 flex items-center justify-center mb-4 group-hover:bg-sky-600 group-hover:text-white transition">
                  <Layers className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base text-slate-900">
                  2. ตลาดกลางซื้อ-ขาย-รับตัด (3 คอลัมน์)
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  แยกกระดานประกาศขาย (ชาวสวน), ประกาศรับซื้อ (ล้ง), และรับจ้างตัดทุเรียน พร้อมกดดูรายละเอียดและทักแชท
                </p>
                <div className="mt-4 text-xs font-bold text-sky-700 flex items-center gap-1">
                  เข้าสู่ตลาดกลาง <ChevronRight className="w-4 h-4" />
                </div>
              </div>

              <div
                onClick={() => setShowRoleRequestModal(true)}
                className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm hover:border-emerald-400 transition cursor-pointer group"
              >
                <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center mb-4 group-hover:bg-amber-600 group-hover:text-white transition">
                  <FileCheck2 className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base text-slate-900">
                  3. ยื่นเอกสารขอเพิ่มบทบาทที่ 2
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  ตอนสมัครเลือกได้ 1 บทบาท ({ROLE_CONFIG[userProfile.primaryRole].shortTitle}) หากต้องการเพิ่มอีกบทบาท ต้องส่งเอกสารให้คัดกรองก่อน
                </p>
                <div className="mt-4 text-xs font-bold text-amber-700 flex items-center gap-1">
                  ส่งเอกสารขอเพิ่มบทบาท <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Matching Posts Preview for Current Role */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-lg text-slate-900">
                    รายการประกาศล่าสุดที่เกี่ยวข้องกับบทบาทของคุณ
                  </h3>
                  <p className="text-xs text-slate-500">
                    คลิก &ldquo;ดูข้อเสนอ&rdquo; เพื่อดูรายละเอียดโพสต์และกดทักแชทพูดคุย
                  </p>
                </div>
                <button
                  onClick={() => setCurrentView("MARKETPLACE")}
                  className="text-xs font-bold text-emerald-700 hover:underline"
                >
                  ดูทั้งหมดในตลาดกลาง &rarr;
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {posts.slice(0, 3).map((post) => (
                  <div
                    key={post.id}
                    className="p-4 rounded-2xl border border-slate-200/90 hover:border-emerald-300 transition bg-slate-50/50 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="font-semibold text-slate-700">
                          {post.authorName}
                        </span>
                        <span className="text-amber-600 font-bold">
                          ★ {post.rating.toFixed(1)}
                        </span>
                      </div>
                      <div className="font-bold text-sm text-slate-900 line-clamp-1">
                        {post.title}
                      </div>
                      <div className="text-xs text-slate-500 mt-1">
                        พันธุ์{post.variety} • จ.{post.province} ({post.regionTag})
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200/70 flex items-center justify-between">
                      <span className="font-extrabold text-emerald-700 text-sm">
                        ฿{post.pricePerKg} / กก.
                      </span>
                      <button
                        onClick={() => handleOpenPostDetail(post)}
                        className="text-xs font-bold px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:border-emerald-500 text-slate-800 transition"
                      >
                        ดูข้อเสนอ
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            VIEW 2: REGIONAL DURIAN DASHBOARD (อ้างอิงรูปที่ 1: ทุเรียนไทยสุกช่วงไหน + ราคา)
           =================================================================== */}
        {currentView === "REGIONAL_DASHBOARD" && (
          <div className="space-y-6">
            {/* Header */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full mb-2">
                  <Sparkles className="w-3.5 h-3.5" />
                  แดชบอร์ดทุเรียนรายภูมิภาค & ฤดูกาลผลผลิต
                </div>
                <h2 className="text-2xl font-extrabold text-slate-900">
                  ทุเรียนไทยสุกช่วงไหน & วิเคราะห์ราคากลางแยกพื้นที่ (6 ภูมิภาค)
                </h2>
                <p className="text-sm text-slate-500 mt-1">
                  คลิกเลือกแต่ละภูมิภาคเพื่อดูจังหวัดแหล่งปลูก สายพันธุ์หลัก ช่วงเดือนที่ผลผลิตออก และกราฟเปรียบเทียบราคาซื้อ-ขายจริง
                </p>
              </div>
            </div>

            {/* Main Grid: Left Regional Map & 6 Cards (ตามรูปที่ 1) + Right Regional Price Analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left 7 Columns: 6 Regional Season Cards + Thailand Regional Map Visual */}
              <div className="lg:col-span-7 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {computedRegionalSeasonsData.map((reg) => {
                    const isSelected = reg.id === selectedRegionalData.id;
                    return (
                      <div
                        key={reg.id}
                        onClick={() => setSelectedRegionId(reg.id)}
                        className={`p-5 rounded-3xl border transition cursor-pointer ${
                          isSelected
                            ? "bg-white border-emerald-600 ring-2 ring-emerald-500/20 shadow-md"
                            : "bg-white border-slate-200/80 hover:border-slate-300 shadow-sm"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span
                              className={`text-sm font-extrabold px-3 py-1 rounded-full border ${reg.colorClass}`}
                            >
                              {reg.regionName}
                            </span>
                            {reg.hasLivePosts && (
                              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded-md flex items-center gap-1">
                                ⚡ ประกาศจริง {reg.livePostsCount}
                              </span>
                            )}
                          </div>
                          <span className="text-xs font-bold text-emerald-700">
                            รับซื้อเฉลี่ย ฿{reg.avgBuyPrice}/กก.
                          </span>
                        </div>

                        {/* Provinces List */}
                        <div className="text-xs text-slate-600 mt-2 leading-relaxed">
                          <strong className="text-slate-800">พื้นที่จังหวัด:</strong>{" "}
                          {reg.provinces.join(" • ")}
                        </div>

                        {/* Varieties */}
                        <div className="text-xs text-slate-600 mt-1.5">
                          <strong className="text-slate-800">สายพันธุ์:</strong>{" "}
                          <span className="font-semibold text-emerald-800">
                            {reg.varieties.join(", ")}
                          </span>
                        </div>

                        {/* Harvest Season Period */}
                        <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-col gap-1">
                          {reg.preSeasonPeriod && (
                            <div className="text-xs flex items-center justify-between">
                              <span className="text-slate-500">ก่อนฤดูกาล:</span>
                              <span className="font-bold text-amber-700">
                                {reg.preSeasonPeriod}
                              </span>
                            </div>
                          )}
                          <div className="text-xs flex items-center justify-between">
                            <span className="text-slate-500 flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                              ผลผลิตช่วง:
                            </span>
                            <span className="font-extrabold text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded-lg">
                              {reg.harvestPeriod}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* วิธีดูทุเรียนสุก (อ้างอิงมุมขวาล่างของรูปที่ 1) */}
                <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-sm flex items-start gap-4">
                  <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
                    <Info className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm text-slate-900">
                      วิธีดูทุเรียนสุก / พร้อมตัดมาตรฐานตลาดกลาง
                    </h4>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      <strong>ก้านแข็งมีสีเข้ม</strong> • <strong>ผิวเป็นเม็ดทราย</strong> •{" "}
                      <strong>ปลายหนามแห้งสีน้ำตาล เปราะหักง่าย</strong> •{" "}
                      <strong>ร่องพูเป็นรอยแยกเห็นชัด</strong> และควรตรวจวัดเปอร์เซ็นต์แป้งในเนื้อทุเรียนตามเกณฑ์มาตรฐานส่งออก (หมอนทอง $\ge 32\%$)
                    </p>
                  </div>
                </div>
              </div>

              {/* Right 5 Columns: Selected Region Price Chart & Variety Breakdown */}
              <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div>
                      <span className="text-xs font-bold text-emerald-700">
                        เจาะลึกข้อมูลราคารายพื้นที่
                      </span>
                      <h3 className="text-xl font-extrabold text-slate-900 mt-0.5">
                        {selectedRegionalData.regionName}
                      </h3>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-slate-500">ช่วงผลผลิตออก</div>
                      <div className="text-sm font-extrabold text-emerald-800">
                        {selectedRegionalData.harvestPeriod}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 mt-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                    {selectedRegionalData.highlightNote}
                  </p>

                  {/* Key Metrics */}
                  <div className="grid grid-cols-3 gap-2.5 my-5">
                    <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-100 text-center">
                      <div className="text-[11px] text-emerald-700 font-medium">
                        ขายหน้าสวนเฉลี่ย
                      </div>
                      <div className="text-lg font-extrabold text-emerald-900 mt-0.5">
                        ฿{selectedRegionalData.avgSellPrice}
                      </div>
                    </div>
                    <div className="p-3 rounded-2xl bg-sky-50/70 border border-sky-100 text-center">
                      <div className="text-[11px] text-sky-700 font-medium">
                        รับซื้อหน้าล้งเฉลี่ย
                      </div>
                      <div className="text-lg font-extrabold text-sky-900 mt-0.5">
                        ฿{selectedRegionalData.avgBuyPrice}
                      </div>
                    </div>
                    <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-100 text-center">
                      <div className="text-[11px] text-amber-700 font-medium">
                        ค่าจ้างตัดเฉลี่ย
                      </div>
                      <div className="text-lg font-extrabold text-amber-900 mt-0.5">
                        ฿{selectedRegionalData.avgCutWage}/กก.
                      </div>
                    </div>
                  </div>

                  {(selectedRegionalData as any).hasLivePosts && (
                    <div className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-3.5 py-2 rounded-2xl border border-emerald-200 flex items-center gap-2 mb-4 shadow-xs">
                      <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div>
                        <span>คำนวณสดจากประกาศจริง {(selectedRegionalData as any).livePostsCount} รายการใน{selectedRegionalData.regionName}</span>
                        <span className="text-[10px] font-normal text-emerald-600 block">อัปเดตราคาซื้อ-ขาย และกราฟแท่งตามข้อมูลจริงในตลาดกลาง</span>
                      </div>
                    </div>
                  )}

                  {/* Bar Comparison by Variety in Selected Region */}
                  <div className="space-y-3.5 mt-4">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                      <span>ราคาทุเรียนแต่ละสายพันธุ์ใน{selectedRegionalData.regionName}</span>
                      <span>(บาท/กก.)</span>
                    </div>

                    {selectedRegionalData.priceByVariety.map((pv, i) => {
                      const maxBar = 520;
                      const buyW = Math.min(
                        100,
                        Math.max(18, Math.round((pv.buyPrice / maxBar) * 100))
                      );
                      const sellW = Math.min(
                        100,
                        Math.max(20, Math.round((pv.sellPrice / maxBar) * 100))
                      );
                      return (
                        <div
                          key={i}
                          className="p-3.5 rounded-2xl border border-slate-100 bg-slate-50/60 space-y-2"
                        >
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-slate-900">
                              พันธุ์{pv.variety}
                            </span>
                            <span className="text-slate-500">
                              อ้างอิงกลาง ฿{pv.refPrice}
                            </span>
                          </div>

                          <div className="space-y-1.5">
                            <div className="flex items-center gap-2 text-[11px]">
                              <span className="w-20 text-slate-500">สวนเสนอขาย:</span>
                              <div className="flex-1 h-2.5 bg-slate-200/70 rounded-full overflow-hidden">
                                <div
                                  style={{ width: `${sellW}%` }}
                                  className="h-full bg-emerald-600 rounded-full"
                                />
                              </div>
                              <span className="w-14 text-right font-bold text-emerald-700">
                                ฿{pv.sellPrice}
                              </span>
                            </div>

                            <div className="flex items-center gap-2 text-[11px]">
                              <span className="w-20 text-slate-500">ล้งรับซื้อ:</span>
                              <div className="flex-1 h-2.5 bg-slate-200/70 rounded-full overflow-hidden">
                                <div
                                  style={{ width: `${buyW}%` }}
                                  className="h-full bg-sky-600 rounded-full"
                                />
                              </div>
                              <span className="w-14 text-right font-bold text-sky-700">
                                ฿{pv.buyPrice}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <button
                  onClick={() => {
                    setSelectedRegionFilter(selectedRegionalData.regionName);
                    setCurrentView("MARKETPLACE");
                  }}
                  className="mt-6 w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm py-3 rounded-2xl transition shadow-sm"
                >
                  ดูประกาศซื้อ-ขายของ{selectedRegionalData.regionName}ในตลาดกลาง &rarr;
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            VIEW 3: MARKETPLACE 3-COLUMN BOARD (อ้างอิงรูปที่ 2 ในโทนสว่างโมเดิร์น)
           =================================================================== */}
        {currentView === "MARKETPLACE" && (
          <div className="space-y-5">
            {/* Top Banner & Variety Item Strip (เหมือนแถบไอเทมด้านบนในรูปที่ 2) */}
            <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-sm space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">
                    ตลาดกลางซื้อ-ขาย-รับตัดทุเรียน (Durian Exchange Board)
                  </h2>
                  <p className="text-xs text-slate-500">
                    เลือกสายพันธุ์ทุเรียนด้านล่างเพื่อกรองรายการ หรือกด &ldquo;ดูข้อเสนอ&rdquo; เพื่อเข้าดูรายละเอียดและทักแชท
                  </p>
                </div>

                <button
                  onClick={() => handleOpenCreatePostModal()}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-sm transition flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  {ROLE_CONFIG[userProfile.activeRole].actionLabel}
                </button>
              </div>

              {/* Horizontal Variety Cards Strip (อ้างอิงแถบการ์ดไอเทมเรียงกันในรูปที่ 2) */}
              <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
                {VARIETY_STRIP_ITEMS.map((item) => {
                  const active = selectedVarietyStrip === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setSelectedVarietyStrip(item.id)}
                      className={`group relative shrink-0 w-32 p-3 rounded-2xl border text-left transition ${
                        active
                          ? "bg-emerald-900 text-white border-emerald-800 shadow-sm"
                          : "bg-slate-50/80 hover:bg-white text-slate-800 border-slate-200"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            active
                              ? "bg-lime-400 text-emerald-950"
                              : "bg-emerald-100 text-emerald-800"
                          }`}
                        >
                          {item.badgeText}
                        </span>
                        <span
                          className={`w-2 h-2 rounded-full bg-gradient-to-r ${item.accentColor}`}
                        />
                      </div>
                      <div className="font-extrabold text-sm mt-2 truncate">
                        {item.nameTh}
                      </div>
                      <div
                        className={`text-[11px] ${
                          active ? "text-emerald-200" : "text-slate-500"
                        }`}
                      >
                        เฉลี่ย ฿{item.avgPrice}/กก.
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Search & Filter Row (อ้างอิงแถบค้นหาและปุ่มขวาในรูปที่ 2) */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
                <div className="flex flex-wrap items-center gap-2.5 flex-1">
                  <select
                    value={selectedRegionFilter}
                    onChange={(e) => setSelectedRegionFilter(e.target.value)}
                    className="text-xs font-semibold border border-slate-200 rounded-xl px-3.5 py-2.5 bg-slate-50 text-slate-700 focus:outline-none"
                  >
                    <option value="ALL">ทุกภูมิภาค</option>
                    <option value="ภาคตะวันออก">ภาคตะวันออก</option>
                    <option value="ภาคใต้">ภาคใต้</option>
                    <option value="ภาคเหนือ">ภาคเหนือ</option>
                    <option value="ภาคกลาง">ภาคกลาง</option>
                    <option value="ภาคอีสาน">ภาคอีสาน</option>
                    <option value="3 จังหวัดชายแดนใต้">3 จังหวัดชายแดนใต้</option>
                  </select>

                  <div className="relative flex-1 min-w-[200px] max-w-sm">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="ค้นหาสายพันธุ์, จังหวัด, หรือชื่อสวน/ล้ง..."
                      className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  {(selectedVarietyStrip !== "ALL" ||
                    selectedRegionFilter !== "ALL" ||
                    searchQuery !== "") && (
                    <button
                      onClick={() => {
                        setSelectedVarietyStrip("ALL");
                        setSelectedRegionFilter("ALL");
                        setSearchQuery("");
                      }}
                      className="text-xs text-slate-500 hover:text-slate-800 px-2.5 py-1.5"
                    >
                      ล้างตัวกรอง
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
                    รายการทั้งหมด {filteredMarketplacePosts.length} โพสต์
                  </span>
                </div>
              </div>
            </div>

            {/* 3 Columns Marketplace Board (Sell Orders | Buy Orders | Cut Service Orders) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              {/* COLUMN 1: SELL ORDERS (โพสต์ขายทุเรียน - ชาวสวน) */}
              <div className="space-y-3">
                <div className="bg-white px-4 py-3 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    <span className="font-extrabold text-sm text-slate-900">
                      โพสต์ขายทุเรียน (Sell Orders)
                    </span>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700">
                    {sellOrders.length}
                  </span>
                </div>

                {sellOrders.map((post) => (
                  <div
                    key={post.id}
                    className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm hover:border-emerald-400 transition space-y-3"
                  >
                    {/* Card Header: User + Rating + Time + ดูข้อเสนอ */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center shrink-0">
                          {post.authorName.charAt(0)}
                        </div>
                        <span className="text-xs font-bold text-slate-800 truncate">
                          {post.authorName}
                        </span>
                        <span className="inline-flex items-center gap-0.5 text-[11px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 shrink-0">
                          ★ {post.rating.toFixed(1)}
                        </span>
                      </div>

                      <button
                        onClick={() => handleOpenPostDetail(post)}
                        className="text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-700 hover:text-white text-slate-700 transition shrink-0"
                      >
                        ดูข้อเสนอ
                      </button>
                    </div>

                    {/* Badges Row */}
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                        ต้องการขาย • {(post.quantityKg / 1000).toFixed(1)} ตัน
                      </span>
                      <span className="text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {post.createdAt}
                      </span>
                    </div>

                    {/* Item -> Offer Price Box (เหมือนโครงสร้างการ์ดในรูปที่ 2) */}
                    <div className="grid grid-cols-12 items-center gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="col-span-7 flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-amber-100/80 border border-amber-200 flex items-center justify-center text-base shrink-0">
                          👑
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            พันธุ์{post.variety} ({post.grade})
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            จ.{post.province} • แป้ง {post.dryMatterPct || 33}%
                          </div>
                        </div>
                      </div>

                      <div className="col-span-1 text-center text-slate-400 font-bold">
                        &rarr;
                      </div>

                      <div className="col-span-4 bg-emerald-50/90 border border-emerald-200/80 rounded-lg px-2.5 py-1.5 text-right">
                        <div className="text-[10px] text-emerald-700 font-medium">
                          ราคาขาย
                        </div>
                        <div className="text-xs font-extrabold text-emerald-900">
                          ฿{post.pricePerKg} /กก.
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* COLUMN 2: BUY ORDERS (โพสต์รับซื้อทุเรียน - ล้ง) */}
              <div className="space-y-3">
                <div className="bg-white px-4 py-3 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
                    <span className="font-extrabold text-sm text-slate-900">
                      โพสต์รับซื้อหน้าล้ง (Buy Orders)
                    </span>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-sky-50 text-sky-700">
                    {buyOrders.length}
                  </span>
                </div>

                {buyOrders.map((post) => (
                  <div
                    key={post.id}
                    className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm hover:border-sky-400 transition space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-7 h-7 rounded-full bg-sky-100 text-sky-800 font-bold text-xs flex items-center justify-center shrink-0">
                          {post.authorName.charAt(0)}
                        </div>
                        <span className="text-xs font-bold text-slate-800 truncate">
                          {post.authorName}
                        </span>
                        <span className="inline-flex items-center gap-0.5 text-[11px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 shrink-0">
                          ★ {post.rating.toFixed(1)}
                        </span>
                      </div>

                      <button
                        onClick={() => handleOpenPostDetail(post)}
                        className="text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-sky-600 hover:text-white text-slate-700 transition shrink-0"
                      >
                        ดูข้อเสนอ
                      </button>
                    </div>

                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold px-2.5 py-0.5 rounded-md bg-sky-50 text-sky-700 border border-sky-200">
                        ต้องการซื้อ • รับ {(post.quantityKg / 1000).toFixed(0)} ตัน
                      </span>
                      <span className="text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {post.createdAt}
                      </span>
                    </div>

                    <div className="grid grid-cols-12 items-center gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="col-span-7 flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-sky-100/80 border border-sky-200 flex items-center justify-center text-base shrink-0">
                          🏢
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            รับซื้อ{post.variety} ({post.grade})
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            ล้ง จ.{post.province} ({post.regionTag})
                          </div>
                        </div>
                      </div>

                      <div className="col-span-1 text-center text-slate-400 font-bold">
                        &rarr;
                      </div>

                      <div className="col-span-4 bg-sky-50/90 border border-sky-200/80 rounded-lg px-2.5 py-1.5 text-right">
                        <div className="text-[10px] text-sky-700 font-medium">
                          ราคารับซื้อ
                        </div>
                        <div className="text-xs font-extrabold text-sky-900">
                          ฿{post.pricePerKg} /กก.
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* COLUMN 3: CUT SERVICE ORDERS (โพสต์รับตัดทุเรียน - ทีมตัด) */}
              <div className="space-y-3">
                <div className="bg-white px-4 py-3 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <span className="font-extrabold text-sm text-slate-900">
                      โพสต์รับตัดทุเรียน (Cut Service)
                    </span>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-700">
                    {cutOrders.length}
                  </span>
                </div>

                {cutOrders.map((post) => (
                  <div
                    key={post.id}
                    className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm hover:border-amber-400 transition space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-7 h-7 rounded-full bg-amber-100 text-amber-800 font-bold text-xs flex items-center justify-center shrink-0">
                          {post.authorName.charAt(0)}
                        </div>
                        <span className="text-xs font-bold text-slate-800 truncate">
                          {post.authorName}
                        </span>
                        <span className="inline-flex items-center gap-0.5 text-[11px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 shrink-0">
                          ★ {post.rating.toFixed(1)}
                        </span>
                      </div>

                      <button
                        onClick={() => handleOpenPostDetail(post)}
                        className="text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-amber-600 hover:text-white text-slate-700 transition shrink-0"
                      >
                        ดูข้อเสนอ
                      </button>
                    </div>

                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold px-2.5 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200">
                        รับจ้างตัดทุเรียน • คิวว่าง {post.availableDate}
                      </span>
                      <span className="text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {post.createdAt}
                      </span>
                    </div>

                    <div className="grid grid-cols-12 items-center gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="col-span-7 flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-amber-100/80 border border-amber-200 flex items-center justify-center text-base shrink-0">
                          ✂️
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            {post.title}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            โซนรับงาน: จ.{post.province} ({post.regionTag})
                          </div>
                        </div>
                      </div>

                      <div className="col-span-1 text-center text-slate-400 font-bold">
                        &rarr;
                      </div>

                      <div className="col-span-4 bg-amber-50/90 border border-amber-200/80 rounded-lg px-2.5 py-1.5 text-right">
                        <div className="text-[10px] text-amber-700 font-medium">
                          ค่าแรงตัด
                        </div>
                        <div className="text-xs font-extrabold text-amber-900">
                          ฿{post.pricePerKg} /กก.
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Floating Action Button (+) มุมขวาล่างเหมือนในรูปที่ 2 */}
            <button
              onClick={() => handleOpenCreatePostModal()}
              title={ROLE_CONFIG[userProfile.activeRole].actionLabel}
              className="fixed bottom-6 right-6 z-20 w-14 h-14 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white shadow-lg flex items-center justify-center transition hover:scale-105"
            >
              <Plus className="w-6 h-6" />
            </button>
          </div>
        )}

        {/* ===================================================================
            VIEW 4: POST DETAIL VIEW (อ้างอิงรูปที่ 3: รูปซ้าย + การ์ดราคาและปุ่มทักแชทขวา)
           =================================================================== */}
        {currentView === "POST_DETAIL" && (
          <div className="max-w-5xl mx-auto space-y-6">
            {/* Back Button */}
            <button
              onClick={() => setCurrentView("MARKETPLACE")}
              className="inline-flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-900 tracking-wide uppercase"
            >
              <ArrowLeft className="w-4 h-4" /> BACK กลับสู่หน้าตลาดกลาง
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Left 6 Columns: Visual Product Showcase + ITEM DETAIL Box (ตามรูปที่ 3) */}
              <div className="lg:col-span-6 space-y-5 flex flex-col items-center">
                <div className="w-full aspect-square max-w-md rounded-3xl bg-gradient-to-br from-emerald-50 via-amber-50/60 to-white border border-slate-200/80 shadow-sm flex flex-col items-center justify-center p-8 relative overflow-hidden">
                  <div className="w-44 h-44 rounded-full bg-amber-200/40 blur-2xl absolute" />
                  <div className="relative z-10 text-center space-y-3">
                    <div className="text-7xl">
                      {selectedPost.postType === "SELL"
                        ? "👑"
                        : selectedPost.postType === "BUY"
                        ? "🏢"
                        : "✂️"}
                    </div>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 border border-slate-200 text-xs font-bold text-slate-800 shadow-sm">
                      พันธุ์{selectedPost.variety} • เกรด {selectedPost.grade}
                    </div>
                    <p className="text-xs text-slate-500 max-w-xs">
                      พื้นที่: อ.{selectedPost.district} จ.{selectedPost.province} (
                      {selectedPost.regionTag})
                    </p>
                  </div>
                </div>

                {/* ITEM DETAIL Box ด้านล่างรูป (เหมือนในรูปที่ 3) */}
                <div className="w-full max-w-md bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
                  <div className="flex items-center gap-1.5 text-xs font-extrabold text-amber-600 uppercase tracking-wider mb-1.5">
                    <Info className="w-4 h-4" /> DURIAN LOT DETAIL (รายละเอียดผลผลิต)
                  </div>
                  <p className="text-sm text-slate-700 leading-relaxed">
                    {selectedPost.content}
                  </p>
                  <div className="mt-3 pt-3 border-t border-slate-100 text-xs text-slate-500">
                    {selectedPost.itemDetailSummary}
                  </div>
                </div>
              </div>

              {/* Right 6 Columns: White Summary Card (ตามรูปที่ 3 ทุกองค์ประกอบ) */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-md space-y-5">
                {/* Top Tags & Date */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span
                      className={`text-xs font-extrabold px-2.5 py-1 rounded-md ${
                        selectedPost.postType === "SELL"
                          ? "bg-emerald-600 text-white"
                          : selectedPost.postType === "BUY"
                          ? "bg-sky-600 text-white"
                          : "bg-amber-500 text-white"
                      }`}
                    >
                      {selectedPost.postType === "SELL"
                        ? "ขาย"
                        : selectedPost.postType === "BUY"
                        ? "รับซื้อ"
                        : "รับตัด"}
                    </span>
                    <span className="text-xs font-extrabold px-2.5 py-1 rounded-md bg-amber-400 text-slate-950">
                      เกรด {selectedPost.grade}
                    </span>
                    <span className="text-xs font-extrabold px-2.5 py-1 rounded-md bg-sky-600 text-white">
                      {selectedPost.regionTag}
                    </span>
                  </div>

                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> {selectedPost.availableDate}
                  </span>
                </div>

                {/* Title */}
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                  {selectedPost.title}
                </h1>

                {/* Price Grey Box */}
                <div className="bg-slate-100/80 rounded-2xl p-4 border border-slate-200/60">
                  <div className="text-xs text-slate-500 font-medium">
                    {selectedPost.postType === "SELL"
                      ? "ราคาเสนอขายหน้าสวน"
                      : selectedPost.postType === "BUY"
                      ? "ราคารับซื้อหน้าล้ง"
                      : "อัตราค่าจ้างตัดทุเรียน"}
                  </div>
                  <div className="mt-1 flex items-baseline gap-2">
                    <span className="text-3xl font-black text-slate-900">
                      {selectedPost.pricePerKg} THB
                    </span>
                    <span className="text-sm text-slate-500">
                      / {selectedPost.priceUnitLabel} (ปริมาณรวม{" "}
                      {(selectedPost.quantityKg / 1000).toFixed(1)} ตัน)
                    </span>
                  </div>
                </div>

                {/* Seller / Poster Profile Card */}
                <div className="rounded-2xl p-4 border border-slate-200 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-emerald-800 text-white font-bold text-lg flex items-center justify-center relative">
                      {selectedPost.authorName.charAt(0)}
                      <span className="w-3 h-3 rounded-full bg-emerald-400 border-2 border-white absolute bottom-0 right-0" />
                    </div>
                    <div>
                      <div className="font-extrabold text-base text-slate-900 flex items-center gap-1.5">
                        {selectedPost.authorName}
                        {selectedPost.isKycVerified && (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        )}
                      </div>
                      <div className="text-xs text-emerald-600 font-medium">
                        {selectedPost.businessName} • {selectedPost.contactNote}
                      </div>
                    </div>
                  </div>

                  {/* Stats Pills: Rating | คะแนนเครดิต | ชมร้านค้า */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                      {selectedPost.rating.toFixed(1)} ({selectedPost.reviewCount})
                    </span>
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      คะแนน {selectedPost.trustScore}
                    </span>
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-slate-100 text-slate-700 font-semibold">
                      <Store className="w-3.5 h-3.5" /> จ.{selectedPost.province}
                    </span>
                  </div>
                </div>

                {/* Main CTA Button: ซื้อสินค้า / ทักแชท (เปิด Modal รูปที่ 4) */}
                <div className="space-y-2">
                  <button
                    onClick={() => setShowChatConfirmModal(true)}
                    className="w-full bg-slate-900 hover:bg-emerald-800 text-white font-bold py-4 px-6 rounded-full transition shadow-md flex items-center justify-center gap-2 text-base"
                  >
                    <MessageSquare className="w-5 h-5" />
                    {selectedPost.postType === "SELL"
                      ? "ซื้อสินค้า / ทักแชทเจรจา"
                      : selectedPost.postType === "BUY"
                      ? "ติดต่อขายให้ล้งนี้ / ทักแชท"
                      : "จองคิวทีมตัด / ทักแชท"}
                  </button>
                  <div className="text-center text-[11px] text-slate-400 flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Authorized Chat Protocol •
                    Secure Data Link Established
                  </div>
                </div>

                {/* Bottom Share / Copy Buttons (ตามรูปที่ 3) */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setCopiedBanner(true);
                      setTimeout(() => setCopiedBanner(false), 2500);
                    }}
                    className="py-2.5 px-4 rounded-xl bg-[#1877F2] hover:bg-[#166fe5] text-white font-bold text-xs flex items-center justify-center gap-2 transition"
                  >
                    <Share2 className="w-4 h-4" /> แชร์ลง Facebook
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCopiedBanner(true);
                      setTimeout(() => setCopiedBanner(false), 2500);
                    }}
                    className="py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition"
                  >
                    <Copy className="w-4 h-4" /> คัดลอกโพสต์ลงกลุ่ม
                  </button>
                </div>

                {copiedBanner && (
                  <div className="text-center text-xs text-emerald-700 font-semibold bg-emerald-50 py-2 rounded-xl">
                    คัดลอกลิงก์และรายละเอียดประกาศเรียบร้อยแล้ว!
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            VIEW 5: CHAT ROOM MESSENGER (อ้างอิงรูปที่ 5: รายชื่อซ้าย + แชท & การ์ดสินค้าขวา + ปุ่มข้อความด่วน)
           =================================================================== */}
        {currentView === "CHAT_ROOM" &&
          (chatRooms.length === 0 || !activeChatRoom ? (
            <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-12 text-center min-h-[500px] flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 mb-4">
                <MessageSquare className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">ยังไม่มีรายการสนทนา</h3>
              <p className="text-sm text-slate-500 max-w-md mb-6">
                คุณยังไม่มีประวัติการพูดคุยกับผู้ซื้อหรือผู้ขาย สามารถเลือกดูประกาศในตลาดกลาง แล้วกด &quot;ติดต่อผู้ขาย / เจรจาซื้อขาย&quot; เพื่อเริ่มคุยได้ทันที
              </p>
              <button
                onClick={() => setCurrentView("MARKETPLACE")}
                className="px-6 py-2.5 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm transition shadow-sm flex items-center gap-2"
              >
                <Store className="w-4 h-4" /> ไปที่ตลาดกลางทุเรียน
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[640px]">
              {/* Left 4 Columns: Chat List Sidebar */}
              <div className="lg:col-span-4 border-r border-slate-200 flex flex-col bg-slate-50/50">
                <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-white">
                  <div className="flex items-center gap-2 font-extrabold text-slate-900 text-base">
                    <MessageSquare className="w-5 h-5 text-amber-500" />
                    ข้อความสนทนา
                  </div>
                  <span className="text-xs text-slate-400">
                    {chatRooms.length} ห้องแชท
                  </span>
                </div>

                <div className="divide-y divide-slate-100 overflow-y-auto flex-1">
                  {chatRooms.map((room) => {
                    const isSelected = room.id === activeChatRoom.id;
                    return (
                      <button
                        key={room.id}
                        onClick={() => setActiveChatRoomId(room.id)}
                        className={`w-full p-4 text-left flex items-start gap-3 transition ${
                          isSelected
                            ? "bg-emerald-50/90 border-l-4 border-l-emerald-600"
                            : "hover:bg-white"
                        }`}
                      >
                        <div className="w-11 h-11 rounded-full bg-emerald-800 text-white font-bold flex items-center justify-center shrink-0">
                          {room.partnerName.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-sm text-slate-900 truncate">
                              {room.partnerName}
                            </span>
                            <span className="text-[11px] text-slate-400">
                              {room.lastTime}
                            </span>
                          </div>
                          <div className="text-xs font-semibold text-amber-700 truncate mt-0.5">
                            📦 {room.post.title}
                          </div>
                          <div className="text-xs text-slate-500 truncate mt-0.5">
                            {room.lastMessage}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Right 8 Columns: Active Chat Window (ตามรูปที่ 5) */}
              <div className="lg:col-span-8 flex flex-col justify-between bg-white">
                {/* Chat Header */}
                <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-800 text-white font-bold flex items-center justify-center">
                      {activeChatRoom.partnerName.charAt(0)}
                    </div>
                    <div>
                      <div className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                        {activeChatRoom.partnerName}
                        <span className="text-xs font-normal text-slate-400">
                          ({activeChatRoom.lastActive})
                        </span>
                      </div>
                      <div className="text-xs font-bold text-amber-600">
                        📦 {activeChatRoom.post.title}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        const pricePerKg = activeChatRoom.post?.pricePerKg || 170;
                        const qty = activeChatRoom.post?.quantityKg || 5000;
                        setDealAgreedPricePerKg(String(pricePerKg));
                        setDealAgreedQty(String(qty));
                        setDealAgreedPrice(String(pricePerKg * qty));
                        setDealSuccessMsg(null);
                        setDealErrorMsg(null);
                        setShowCloseDealModal(true);
                      }}
                      className="px-3.5 py-1.5 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-sm"
                    >
                      <Handshake className="w-3.5 h-3.5" /> ตกลงราคา (ปิดดีล)
                    </button>
                    <button
                      onClick={() => handleOpenPostDetail(activeChatRoom.post)}
                      className="px-3.5 py-1.5 rounded-full bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-xs transition flex items-center gap-1"
                    >
                      <Store className="w-3.5 h-3.5" /> ดูประกาศสวน/ล้ง
                    </button>
                    <button
                      onClick={() =>
                        handleSendMessage(
                          "⭐ ขอขอบคุณสำหรับการเจรจาซื้อขายครับ (ให้คะแนนรีวิว 5.0 ดาว)"
                        )
                      }
                      className="px-3.5 py-1.5 rounded-full bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs transition flex items-center gap-1"
                    >
                      <Star className="w-3.5 h-3.5" /> รีวิวคู่ค้า
                    </button>
                  </div>
                </div>

              {/* Chat Messages Body + Product Reference Card (เหมือนในรูปที่ 5) */}
              <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/40">
                {(activeChatRoom.messages || []).length === 0 && (
                  <div className="h-48 flex flex-col items-center justify-center text-center p-6 text-slate-400">
                    <MessageSquare className="w-8 h-8 text-slate-300 mb-2" />
                    <p className="text-xs">เริ่มต้นการเจรจา หรือพิมพ์ข้อความพูดคุยได้เลยครับ</p>
                  </div>
                )}
                {(activeChatRoom.messages || []).map((msg) => {
                  if (msg.isProductCard) {
                    return (
                      <div key={msg.id} className="flex justify-end">
                        <div className="flex items-end gap-2">
                          <span className="text-[11px] text-slate-400">
                            ส่งแล้ว {msg.time}
                          </span>
                          {/* Product Card Bubble inside Chat (ตามรูปที่ 5) */}
                          <div className="w-60 bg-white rounded-2xl border border-slate-200 shadow-sm p-3.5 space-y-3">
                            <div className="relative rounded-xl bg-gradient-to-br from-emerald-50 to-amber-50 h-32 flex items-center justify-center border border-slate-100">
                              <span className="absolute top-2 right-2 bg-amber-400 text-slate-950 text-xs font-black px-2.5 py-0.5 rounded-md shadow-sm">
                                {activeChatRoom.post.pricePerKg} THB/กก.
                              </span>
                              <span className="text-5xl">👑</span>
                            </div>
                            <div>
                              <div className="text-[11px] font-bold text-amber-600">
                                สนใจสินค้า:
                              </div>
                              <div className="font-extrabold text-sm text-slate-900 line-clamp-1">
                                {activeChatRoom.post.title}
                              </div>
                              <div className="text-[11px] text-slate-500 mt-0.5">
                                จ.{activeChatRoom.post.province} • ปริมาณ{" "}
                                {(activeChatRoom.post.quantityKg / 1000).toFixed(1)}{" "}
                                ตัน
                              </div>
                            </div>
                            <button
                              onClick={() =>
                                handleOpenPostDetail(activeChatRoom.post)
                              }
                              className="w-full py-2 rounded-full bg-slate-900 hover:bg-emerald-800 text-white text-xs font-bold transition"
                            >
                              ดูรายละเอียด
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={msg.id}
                      className={`flex ${
                        msg.sender === "ME" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-md px-4 py-2.5 rounded-2xl text-sm ${
                          msg.sender === "ME"
                            ? "bg-emerald-700 text-white rounded-br-none"
                            : "bg-white border border-slate-200 text-slate-800 rounded-bl-none"
                        }`}
                      >
                        <div>{msg.text}</div>
                        <div
                          className={`text-[10px] mt-1 text-right ${
                            msg.sender === "ME"
                              ? "text-emerald-200"
                              : "text-slate-400"
                          }`}
                        >
                          {msg.time}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Bottom Quick Reply Chips + Input Bar (ตามรูปที่ 5) */}
              <div className="p-3.5 bg-white border-t border-slate-200 space-y-2.5">
                {/* Quick Reply Chips */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  {QUICK_REPLY_CHIPS.map((chip, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSendMessage(chip)}
                      className="shrink-0 text-xs font-medium px-3 py-1.5 rounded-full bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 border border-slate-200/80 transition"
                    >
                      {chip}
                    </button>
                  ))}
                </div>

                {/* Message Input Form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage(chatInputText);
                  }}
                  className="flex items-center gap-2"
                >
                  <input
                    type="text"
                    value={chatInputText}
                    onChange={(e) => setChatInputText(e.target.value)}
                    placeholder="พิมพ์ข้อความเจรจาซื้อขาย นัดดูสวน หรือสอบถามเปอร์เซ็นต์แป้ง..."
                    className="flex-1 bg-slate-100 border border-slate-200 rounded-full px-4 py-2.5 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <button
                    type="submit"
                    className="w-10 h-10 rounded-full bg-amber-400 hover:bg-amber-500 text-slate-950 flex items-center justify-center shadow-sm transition shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </div>
          </div>
        ))}
      </main>

      {/* =====================================================================
          MODAL 1: SECURE CHANNEL LINK CONFIRMATION (อ้างอิงตามรูปที่ 4 ทุกจุด)
         ===================================================================== */}
      {showChatConfirmModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Top Header */}
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center gap-2 text-xs font-extrabold text-amber-600 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" /> SECURE CHANNEL LINK
            </div>

            {/* Body */}
            <div className="p-6 text-center space-y-4">
              <div>
                <h3 className="text-xl font-black text-slate-900">
                  คุณต้องการส่งข้อความหรือไม่?
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  คุณกำลังจะเปิดห้องแชทเจรจาสำหรับรายการนี้ โปรดตรวจสอบรายละเอียดก่อนยืนยัน
                </p>
              </div>

              {/* Item Preview Box */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center gap-3.5 text-left">
                <div className="w-12 h-12 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center text-2xl shrink-0">
                  👑
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-extrabold text-sm text-slate-900 truncate">
                    {selectedPost.title}
                  </div>
                  <div className="text-sm font-black text-amber-600">
                    {selectedPost.pricePerKg} THB / กก.
                  </div>
                  <div className="text-xs text-slate-500 truncate">
                    👤 {selectedPost.authorName} ({selectedPost.businessName})
                  </div>
                </div>
              </div>

              {/* Anti-Spam Warning Box */}
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200/90 text-amber-800 text-xs font-semibold flex items-center justify-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                คำเตือน: การกดก่อกวน ปั่นราคา หรือ Spam อาจทำให้บัญชีถูกระงับ
              </div>
            </div>

            {/* Footer Buttons: ยกเลิก | ยืนยัน > */}
            <div className="grid grid-cols-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setShowChatConfirmModal(false)}
                className="py-3.5 text-sm font-bold text-slate-600 hover:bg-slate-100 transition"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                onClick={handleConfirmStartChat}
                className="py-3.5 text-sm font-black bg-amber-400 hover:bg-amber-500 text-slate-950 transition flex items-center justify-center gap-1"
              >
                ยืนยัน <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL 2: CREATE NEW POST MODAL (ตามบทบาทที่ล็อกอิน)
         ===================================================================== */}
      {showCreatePostModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <span
                  className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                    ROLE_CONFIG[userProfile.activeRole].badgeBg
                  }`}
                >
                  ผู้ลงประกาศ: {ROLE_CONFIG[userProfile.activeRole].shortTitle} ({userProfile.fullName})
                </span>
                <h3 className="font-extrabold text-base text-slate-900 mt-1">
                  {newPostType === "SELL"
                    ? "ลงประกาศขายทุเรียนหน้าสวน (Sell Orders)"
                    : newPostType === "BUY"
                    ? "ตั้งประกาศรับซื้อทุเรียนหน้าล้ง (Buy Orders)"
                    : "ลงประกาศคิวว่างรับตัดทุเรียน (Cut Service)"}
                </h3>
              </div>
              <button
                onClick={() => setShowCreatePostModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateNewPost} className="p-6 space-y-3.5 text-sm">
              {/* Category / Column Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  เลือกหมวดหมู่ประกาศ (จะไปแสดงในคอลัมน์ที่เลือก) *
                </label>
                <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 rounded-2xl">
                  <button
                    type="button"
                    onClick={() => {
                      setNewPostType("SELL");
                      setNewPostPrice("172");
                    }}
                    className={`py-2 px-1 text-center text-xs font-bold rounded-xl transition ${
                      newPostType === "SELL"
                        ? "bg-emerald-600 text-white shadow-sm"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    🟢 โพสต์ขายหน้าสวน
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNewPostType("BUY");
                      setNewPostPrice("170");
                    }}
                    className={`py-2 px-1 text-center text-xs font-bold rounded-xl transition ${
                      newPostType === "BUY"
                        ? "bg-sky-600 text-white shadow-sm"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    🔵 รับซื้อหน้าล้ง
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNewPostType("CUT_SERVICE");
                      setNewPostPrice("5.5");
                    }}
                    className={`py-2 px-1 text-center text-xs font-bold rounded-xl transition ${
                      newPostType === "CUT_SERVICE"
                        ? "bg-amber-600 text-white shadow-sm"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    🟡 รับตัดทุเรียน
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  หัวข้อประกาศ
                </label>
                <input
                  type="text"
                  required
                  value={newPostTitle}
                  onChange={(e) => setNewPostTitle(e.target.value)}
                  placeholder={
                    newPostType === "SELL"
                      ? "เช่น หมอนทองเกรดส่งออก AB แป้ง 34% พร้อมตัด 5 ตัน"
                      : newPostType === "BUY"
                      ? "เช่น รับซื้อหมอนทองเกรด AB ให้ราคาสูง จ่ายสดหน้าล้ง"
                      : "เช่น ทีมตัดช่างเอก ระยอง-จันทบุรี คิวว่างพร้อมตัด"
                  }
                  className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    สายพันธุ์ทุเรียน
                  </label>
                  <select
                    value={newPostVariety}
                    onChange={(e) => setNewPostVariety(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white"
                  >
                    {VARIETY_STRIP_ITEMS.filter((v) => v.id !== "ALL").map(
                      (v) => (
                        <option key={v.id} value={v.id}>
                          {v.nameTh}
                        </option>
                      )
                    )}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    เกรดทุเรียน
                  </label>
                  <select
                    value={newPostGrade}
                    onChange={(e) => setNewPostGrade(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white"
                  >
                    <option value="AB ส่งออก">AB ส่งออก</option>
                    <option value="C รอง">เกรด C</option>
                    <option value="คัดพิเศษ GI">คัดพิเศษ GI</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ภูมิภาค
                  </label>
                  <select
                    value={newPostRegion}
                    onChange={(e) => {
                      const regName = e.target.value;
                      setNewPostRegion(regName);
                      const regObj = REGIONAL_SEASONS_DATA.find(
                        (r) => r.regionName === regName
                      );
                      if (regObj && regObj.provinces.length > 0) {
                        setNewPostProvince(regObj.provinces[0]);
                      }
                    }}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white"
                  >
                    {REGIONAL_SEASONS_DATA.map((r) => (
                      <option key={r.id} value={r.regionName}>
                        {r.regionName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    จังหวัด
                  </label>
                  <select
                    value={newPostProvince}
                    onChange={(e) => setNewPostProvince(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-sm bg-white"
                  >
                    {(
                      REGIONAL_SEASONS_DATA.find(
                        (r) => r.regionName === newPostRegion
                      )?.provinces || ["จันทบุรี", "ระยอง", "ตราด"]
                    ).map((prov) => (
                      <option key={prov} value={prov}>
                        {prov}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {newPostType === "CUT_SERVICE"
                      ? "ค่าแรงตัด (บาท/กก.)"
                      : newPostType === "BUY"
                      ? "ราคารับซื้อ (บาท/กก.)"
                      : "ราคาขาย (บาท/กก.)"}
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={newPostPrice}
                    onChange={(e) => setNewPostPrice(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {newPostType === "BUY"
                      ? "ปริมาณที่ต้องการรับซื้อ (กก.)"
                      : "ปริมาณผลผลิต (กก.)"}
                  </label>
                  <input
                    type="number"
                    required
                    value={newPostQty}
                    onChange={(e) => setNewPostQty(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  รายละเอียดเพิ่มเติม
                </label>
                <textarea
                  rows={3}
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  placeholder="ระบุรายละเอียดสวน เปอร์เซ็นต์แป้ง หรือเงื่อนไขการรับซื้อ..."
                  className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-sm"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreatePostModal(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white shadow-sm"
                >
                  ยืนยันการลงประกาศ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL 3: REQUEST 2ND ROLE WITH DOCUMENT VERIFICATION
         ===================================================================== */}
      {showRoleRequestModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-emerald-700">
                  ระบบคัดกรองสมาชิกหลายบทบาท
                </span>
                <h3 className="font-extrabold text-base text-slate-900">
                  ยื่นเอกสารเพื่อขอเพิ่มบทบาทที่ 2 (`role_verification_requests`)
                </h3>
              </div>
              <button
                onClick={() => setShowRoleRequestModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {reqNotice && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-900">
                  {reqNotice}
                </div>
              )}

              <form
                onSubmit={handleSubmitExtraRoleRequest}
                className="space-y-3.5 text-sm"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      บทบาทหลักปัจจุบันของคุณ
                    </label>
                    <input
                      type="text"
                      disabled
                      value={ROLE_CONFIG[userProfile.primaryRole].title}
                      className="w-full border border-slate-200 bg-slate-100 rounded-xl px-3.5 py-2 text-xs font-bold text-slate-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      เลือกบทบาทที่ต้องการขอเพิ่ม
                    </label>
                    <select
                      value={reqTargetRole}
                      onChange={(e) =>
                        setReqTargetRole(e.target.value as RoleType)
                      }
                      className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold bg-white"
                    >
                      {(["SELLER", "BUYER", "CUTTER"] as RoleType[])
                        .filter((r) => r !== userProfile.primaryRole)
                        .map((r) => (
                          <option key={r} value={r}>
                            {ROLE_CONFIG[r].title}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ชื่อกิจการ / ชื่อล้ง / ชื่อทีมตัด
                    </label>
                    <input
                      type="text"
                      required
                      value={reqBizName}
                      onChange={(e) => setReqBizName(e.target.value)}
                      placeholder="ระบุชื่อกิจการสำหรับบทบาทที่ขอเพิ่ม"
                      className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      เลขทะเบียนล้ง / เลข GAP / เลขใบรับรอง
                    </label>
                    <input
                      type="text"
                      required
                      value={reqLicenseNo}
                      onChange={(e) => setReqLicenseNo(e.target.value)}
                      placeholder="เช่น GAP-2569-XXXX"
                      className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    แนบไฟล์เอกสารยืนยันเพื่อคัดกรอง
                  </label>
                  <div className="flex items-center gap-2 border border-dashed border-slate-300 rounded-xl px-3.5 py-2 bg-slate-50">
                    <Upload className="w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      value={reqDocFileName}
                      onChange={(e) => setReqDocFileName(e.target.value)}
                      className="w-full bg-transparent text-xs text-slate-700 focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 rounded-xl text-xs transition"
                >
                  ส่งเอกสารขอเพิ่มบทบาทที่ 2
                </button>
              </form>

              {/* Admin Approval Simulation Box */}
              <div className="pt-4 border-t border-slate-200">
                <div className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-emerald-700" />
                  รายการคำขอเพิ่มบทบาท (จำลองหน้า Admin กดอนุมัติเอกสาร):
                </div>
                <div className="space-y-2">
                  {roleRequests.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2 text-xs"
                    >
                      <div>
                        <div className="font-bold text-slate-900">
                          {item.userName} &rarr; ขอเพิ่มบทบาท{" "}
                          <span className="text-emerald-700">
                            {ROLE_CONFIG[item.requestedRole].shortTitle}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          ไฟล์แนบ: {item.documentName} ({item.licenseNumber})
                        </div>
                      </div>
                      {item.status === "PENDING" ? (
                        <button
                          type="button"
                          onClick={() => handleApproveRoleRequest(item)}
                          className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-bold text-xs shrink-0"
                        >
                          อนุมัติเอกสาร
                        </button>
                      ) : (
                        <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-[11px] shrink-0">
                          อนุมัติแล้ว
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL 5: CLOSE DEAL MODAL (ตกลงราคาซื้อขายและบันทึกสัญญา)
         ===================================================================== */}
      {showCloseDealModal && activeChatRoom && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="px-6 py-4 bg-gradient-to-r from-emerald-800 to-teal-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-lime-300">
                  <Handshake className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">ตกลงราคาซื้อขาย (ปิดดีล)</h3>
                  <p className="text-[11px] text-emerald-200">
                    บันทึกข้อตกลงและราคาระหว่างผู้ซื้อกับผู้ขายลงระบบ
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCloseDealModal(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form Body */}
            <form onSubmit={handleCloseDeal} className="p-6 space-y-4">
              {dealSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  {dealSuccessMsg}
                </div>
              )}

              {dealErrorMsg && (
                <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                  {dealErrorMsg}
                </div>
              )}

              {/* Item Info Box */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center text-xl shrink-0">
                  👑
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-extrabold text-sm text-slate-900 truncate">
                    {activeChatRoom.post?.title}
                  </div>
                  <div className="text-xs text-slate-500">
                    คู่ค้า: {activeChatRoom.partnerName} ({activeChatRoom.partnerBusiness})
                  </div>
                </div>
              </div>

              {/* Price & Quantity Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ราคาตกลง (บาท/กก.) *
                  </label>
                  <input
                    type="number"
                    required
                    value={dealAgreedPricePerKg}
                    onChange={(e) => {
                      const val = e.target.value;
                      setDealAgreedPricePerKg(val);
                      const qty = parseFloat(dealAgreedQty) || 0;
                      if (qty > 0 && val) {
                        setDealAgreedPrice(String(parseFloat(val) * qty));
                      }
                    }}
                    placeholder="เช่น 175"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ปริมาณตกลง (กก.) *
                  </label>
                  <input
                    type="number"
                    required
                    value={dealAgreedQty}
                    onChange={(e) => {
                      const val = e.target.value;
                      setDealAgreedQty(val);
                      const p = parseFloat(dealAgreedPricePerKg) || 0;
                      if (p > 0 && val) {
                        setDealAgreedPrice(String(p * parseFloat(val)));
                      }
                    }}
                    placeholder="เช่น 5000"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ยอดรวมทั้งสิ้น (บาท) *
                </label>
                <input
                  type="number"
                  required
                  value={dealAgreedPrice}
                  onChange={(e) => setDealAgreedPrice(e.target.value)}
                  placeholder="คำนวณอัตโนมัติ"
                  className="w-full bg-emerald-50/60 border border-emerald-200 text-emerald-900 font-extrabold rounded-xl px-3.5 py-2 text-base focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  กำหนดการตัด / ส่งมอบผลผลิต
                </label>
                <input
                  type="date"
                  value={dealCutDate}
                  onChange={(e) => setDealCutDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  บันทึกข้อตกลงเพิ่มเติม (ถ้ามี)
                </label>
                <textarea
                  rows={2}
                  value={dealNote}
                  onChange={(e) => setDealNote(e.target.value)}
                  placeholder="เช่น มัดจำ 10%, ค่าขนส่งผู้ซื้อรับผิดชอบ, ตัดที่เปอร์เซ็นต์แป้ง 32% ขึ้นไป..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowCloseDealModal(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  disabled={isDealLoading}
                  className="px-5 py-2.5 text-xs font-black bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl shadow-sm transition flex items-center gap-1.5"
                >
                  {isDealLoading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      กำลังบันทึกดีล...
                    </>
                  ) : (
                    <>
                      <Handshake className="w-4 h-4" /> ยืนยันปิดดีลซื้อขาย
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
