import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Durian Hub | ตลาดกลางทุเรียนไทยครบวงจร (ชาวสวน • ล้งรับซื้อ • ทีมรับตัด)",
  description:
    "ระบบตลาดกลางทุเรียน วิเคราะห์ราคากลางแบบเรียลไทม์แยกสายพันธุ์และพื้นที่ พร้อมระบบประกาศขาย รับซื้อ และรับจ้างตัดทุเรียนตามบทบาทสมาชิก",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="th">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        {children}
      </body>
    </html>
  );
}
