import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "กรุณาเข้าสู่ระบบก่อนตกลงซื้อขาย" }, { status: 401 });
    }

    const body = await request.json();
    const {
      roomId,
      postId,
      receiverId,
      agreedPrice,
      agreedPricePerKg,
      agreedQuantityKg,
      cutDate,
      note,
    } = body;

    if (!postId || !receiverId || !agreedPrice) {
      return NextResponse.json({ error: "ข้อมูลสำหรับทำรายการซื้อขายไม่ครบถ้วน" }, { status: 400 });
    }

    const post = await prisma.marketplacePost.findUnique({
      where: { id: Number(postId) },
    });

    if (!post) {
      return NextResponse.json({ error: "ไม่พบประกาศสินค้านี้" }, { status: 404 });
    }

    // Create deal
    const deal = await prisma.deal.create({
      data: {
        postId: post.id,
        initiatorId: user.id,
        receiverId: Number(receiverId),
        agreedPrice: Number(agreedPrice),
        agreedPricePerKg: agreedPricePerKg ? Number(agreedPricePerKg) : Number(agreedPrice),
        agreedQuantityKg: agreedQuantityKg ? Number(agreedQuantityKg) : null,
        cutDate: cutDate ? new Date(cutDate) : null,
        note: note ? note.trim() : null,
        status: "ACCEPTED",
      },
    });

    // Send system message in chat room if roomId is provided
    if (roomId) {
      const summaryMsg = `🎉 ตกลงราคาซื้อขาย (ปิดดีล) สำเร็จ!\n• ราคาตกลง: ${Number(agreedPrice).toLocaleString()} บาท${agreedPricePerKg ? ` (${Number(agreedPricePerKg)} บาท/กก.)` : ""}\n• ปริมาณ: ${agreedQuantityKg ? `${Number(agreedQuantityKg).toLocaleString()} กก.` : "ตามตกลง"}\n• สถานะดีล: ยืนยันแล้ว (รหัสดีล #${deal.id})`;

      await prisma.chatMessage.create({
        data: {
          roomId: Number(roomId),
          senderId: user.id,
          messageType: "TEXT",
          content: summaryMsg,
        },
      });

      await prisma.chatRoom.update({
        where: { id: Number(roomId) },
        data: {
          status: "DEAL_CLOSED",
          lastMessageAt: new Date(),
        },
      });
    }

    return NextResponse.json({ success: true, deal });
  } catch (error) {
    console.error("POST Deal Error:", error);
    return NextResponse.json({ error: "ไม่สามารถทำรายการซื้อขายได้" }, { status: 500 });
  }
}
