# 📌 Project State & Active Task Tracker

**Project:** Durian Hub (ตลาดกลางทุเรียน)
**Last Updated:** 2026-10-28
**Current Status:** READY / ACTIVE

---

## 🎯 Current Goal (คำสั่งและเป้าหมายล่าสุด)
- ระบบตลาดกลางทุเรียน (Durian Hub) ตามแผนใน `durian_marketplace_plan.md`
- ติดตั้งระบบ Skill & Rules ป้องกันการลืมงาน และบันทึกสถานะงานแบบไม่ต้องอ่านโค้ดทั้งหมดซ้ำซ้อน
- ระบบสมัคร/ล็อกอินจริง + OTP ยืนยันอีเมล + ลืมรหัสผ่าน (ผู้ใช้เลือก: **บังคับกรอกอีเมลทุกคน**) เทสอีเมลผ่าน Mailpit
- ระบบโพสต์สินค้าจริง + แชทเจรจาซื้อขายสด (Real-time Polling 2 หน้าต่าง) + ปุ่มตกลงราคาปิดดีล (`/api/deals`) บันทึกลงฐานข้อมูล MySQL
- **[งานล่าสุด 2026-10-28]** 
  1. แก้บั๊กหน้าห้องแชทจอแดง (`Cannot read properties of undefined (reading 'map')`)
  2. แก้บั๊กตัวกรองภูมิภาคในตลาดกลาง (เมื่อกดเลือกภูมิภาคแล้วโพสต์ไม่แสดง)
  3. ตรวจสอบและเชื่อมต่อแดชบอร์ดรายพื้นที่ (Regional Dashboard) ให้คำนวณราคาเฉลี่ยและสถิติจากโพสต์จริงในระบบ

## 📍 Where We Are (ตอนนี้ทำอะไรอยู่)
- **Active Focus:** แก้ไขการจับคู่ภูมิภาค "3 จังหวัดชายแดนใต้" เรียบร้อย:
  1. **อัปเดตฐานข้อมูล Location:** แก้ไขจังหวัดยะลา (Location ID 6) ให้มี `region = "3 จังหวัดชายแดนใต้"` และเชื่อมกับ `regionalSeasonId = 3` (DEEP_SOUTH) ทำให้โพสต์ขายหมอน (ID 4) และโพสต์รับซื้อ (ID 9) ปรากฏในหมวด "3 จังหวัดชายแดนใต้" ทันที
  2. **ปรับปรุง API `/api/posts`:** เพิ่มตรรกะตรวจสอบจังหวัด หากเป็น "ยะลา, ปัตตานี, นราธิวาส" หรือผู้ใช้เลือก "3 จังหวัดชายแดนใต้" ระบบจะผูก location กับภูมิภาค "3 จังหวัดชายแดนใต้" เสมอ ไม่ให้หลุดไปเป็น "ภาคใต้"
  3. **ปรับปรุงฟอร์มลงประกาศใน `page.tsx`:** เมื่อผู้ใช้เปลี่ยนภูมิภาคใน Modal ฟิลด์จังหวัดจะกลายเป็น Dropdown ที่เปลี่ยนรายชื่อจังหวัดตามภูมิภาคนั้นๆ อัตโนมัติ ป้องกันการจับคู่ภูมิภาคและจังหวัดผิดพลาด

## 📋 Task Checklist
- [x] สร้าง Skill `task-tracker` สำหรับบันทึกและอ่านสถานะงาน
- [x] สร้างกฎอัตโนมัติ `GEMINI.md` เพื่อบังคับให้อ่าน State ก่อนเริ่มงานทุกครั้ง
- [x] สร้าง Skill `solution-advisor` สำหรับวิเคราะห์จุดบกพร่อง วางแผนขั้นตอน และให้คำปรึกษาเชิงสถาปัตยกรรม
- [x] สรุปแผนผังไฟล์สำคัญ (Key Architecture Map) เพื่อลดการค้นหาโค้ดซ้ำซ้อน
- [x] ปรับปรุง [schema.prisma](file:///d:/csc481/prisma/schema.prisma) และเปลี่ยนเป็น **MySQL**
- [x] สร้างไฟล์ [docker-compose.yml](file:///d:/csc481/docker-compose.yml) (MySQL Container พอร์ต 3307)
- [x] อัปเดต [.env](file:///d:/csc481/.env) เป็นพอร์ต 3307 (`mysql://root:password@localhost:3307/durian_hub`)
- [x] ผู้ใช้ติดตั้งและเปิดใช้งาน Docker Desktop
- [x] สั่ง `docker compose up -d` และ Container ทำงานเรียบร้อย
- [x] รัน `npx prisma db push` ซิงค์ Schema ลงฐานข้อมูล MySQL เรียบร้อย
- [x] Auth: เพิ่ม Mailpit ใน docker-compose (SMTP 1025 / UI 8025)
- [x] Auth: schema — `email` บังคับ, `emailVerifiedAt`, ตาราง `OtpCode`
- [x] Auth: ติดตั้ง bcryptjs, jose, nodemailer + lib (prisma, auth/session, otp, mailer)
- [x] Auth: API register / login / logout / me / verify-email / resend-otp / forgot-password / reset-password
- [x] Auth: Seed ข้อมูลพันธุ์, เกรด, ภูมิภาค และบัญชีทดสอบ 4 บทบาท (`password123`)
- [x] Auth: เชื่อมฟอร์มใน page.tsx + หน้าต่างกรอก OTP + หน้าต่างลืมรหัสผ่าน
- [x] Auth: ตรวจสอบ Type-check (`tsc --noEmit`) ผ่านฉลุย 100%
- [x] Chat/Marketplace: Seed โพสต์สินค้าจริงลง DB สำหรับชาวสวน/ล้ง/ทีมตัด (`prisma/seed.ts`)
- [x] Chat/Marketplace: API `/api/posts` (ดึงโพสต์จาก DB + ลงประกาศใหม่)
- [x] Chat/Marketplace: API `/api/chat/rooms` (ดึงห้องแชท + สร้างห้องแชทสำหรับโพสต์)
- [x] Chat/Marketplace: API `/api/chat/rooms/[id]/messages` (ดึงข้อความ + ส่งข้อความใหม่ลง DB)
- [x] Chat/Marketplace: API `/api/deals` (สร้างดีลตกลงราคาซื้อขาย + ส่งข้อความยืนยันในห้องแชท)
- [x] Chat/Marketplace: เชื่อม Frontend ใน `page.tsx` พร้อม Auto-polling ทุก 2 วินาที (คุยสด 2 หน้าต่าง)
- [x] Chat/Marketplace: เพิ่มปุ่มและ Modal "ตกลงราคา (ปิดดีล)" ในหน้าต่างแชทพร้อมบันทึกสัญญาลง DB
- [x] Bugfix: แก้ไขหน้าห้องแชท Crash `Cannot read properties of undefined (reading 'map')`
- [x] Bugfix: แก้ไขตัวกรองภูมิภาคในหน้าตลาดกลางให้ดึงโพสต์ตามภูมิภาคจริง
- [x] Feature: เชื่อมโยงแดชบอร์ดรายพื้นที่ (Regional Dashboard) ให้คำนวณสถิติและราคาเฉลี่ยแบบสดจากประกาศในฐานข้อมูล
- [x] Bugfix: แก้ไขการแยกหมวดหมู่ "3 จังหวัดชายแดนใต้" (ยะลา, ปัตตานี, นราธิวาส) ไม่ให้ไปปนกับ "ภาคใต้"
- [x] Docker: สร้าง [Dockerfile](file:///d:/csc481/Dockerfile), [.dockerignore](file:///d:/csc481/.dockerignore), [docker-entrypoint.js](file:///d:/csc481/docker-entrypoint.js) และ [docker-compose.yml](file:///d:/csc481/docker-compose.yml) (เพิ่ม service `web`) สำหรับรันระบบทั้งชุดได้ทันทีในเครื่องปลายทาง
- [x] Documentation: สร้าง [README.md](file:///d:/csc481/README.md) อธิบายขั้นตอนการส่งและรันโปรเจกต์ด้วยคำสั่งเดียว

## 🗺️ Key Files & Architecture (แผนผังไฟล์สำคัญ - ไม่ต้องไล่อ่านทั้งโฟลเดอร์)
- [README.md](file:///d:/csc481/README.md) — คู่มือการรันระบบด้วย Docker คำสั่งเดียวสำหรับส่งต่อให้ผู้อื่น
- [Dockerfile](file:///d:/csc481/Dockerfile) — สูตร Build Container สำหรับเว็บ Next.js + Prisma
- [docker-entrypoint.js](file:///d:/csc481/docker-entrypoint.js) — สคริปต์รอ DB พร้อม -> ซิงค์ Schema -> Seed ข้อมูล -> รัน Next.js อัตโนมัติ
- [docker-compose.yml](file:///d:/csc481/docker-compose.yml) — รวม 3 บริการ: `web` (Next.js), `mysql` (Database 3307), `mailpit` (OTP Mailer 8025)
- [durian_marketplace_plan.md](file:///d:/csc481/durian_marketplace_plan.md) — แผนสเปกหน้าจอ 6 หน้าจอ และ User Flow
- [page.tsx](file:///d:/csc481/src/app/page.tsx) — หน้าบ้านหลัก (Next.js) เชื่อมต่อ API ล็อกอิน, โพสต์สินค้า, แชทสด Real-time polling, ปิดดีล และคำนวณแดชบอร์ดสด
- [prisma/schema.prisma](file:///d:/csc481/prisma/schema.prisma) — Database Schema สำหรับ MySQL (รวม User, OtpCode, Post, Chat, Deal)
- [prisma/seed.ts](file:///d:/csc481/prisma/seed.ts) — สคริปต์ Seed พันธุ์ทุเรียน เกรด ภูมิภาค บัญชีทดสอบ และโพสต์สินค้า
- [src/app/api/posts/route.ts](file:///d:/csc481/src/app/api/posts/route.ts) — API โพสต์สินค้าในตลาดกลาง (GET/POST) พร้อมแมป regionTag และแยก 3 จังหวัดชายแดนใต้
- [src/app/api/chat/rooms/route.ts](file:///d:/csc481/src/app/api/chat/rooms/route.ts) — API ห้องแชท (GET/POST) พร้อมโหลดข้อความทั้งหมด
- [src/app/api/chat/rooms/[id]/messages/route.ts](file:///d:/csc481/src/app/api/chat/rooms/[id]/messages/route.ts) — API ข้อความแชท (GET/POST)
- [src/app/api/deals/route.ts](file:///d:/csc481/src/app/api/deals/route.ts) — API ตกลงราคาปิดดีลซื้อขายและส่งการยืนยันเข้าห้องแชท
- [src/lib/auth.ts](file:///d:/csc481/src/lib/auth.ts) — เข้ารหัสรหัสผ่าน (bcrypt) + JWT Session Cookie (jose)
- [src/lib/otp.ts](file:///d:/csc481/src/lib/otp.ts) — สร้างรหัส OTP 6 หลัก, จำกัดเวลา 10 นาที, นับรอบผิด, ป้องกันสแปม 60 วินาที
- [src/lib/mail.ts](file:///d:/csc481/src/lib/mail.ts) — ส่งอีเมลเทมเพลต HTML เข้า Mailpit (พอร์ต 1025)
- [CURRENT_TASK.md](file:///d:/csc481/CURRENT_TASK.md) — ไฟล์สถานะงานปัจจุบัน (ไฟล์นี้)

## ⏭️ Next Steps (สิ่งที่จะทำต่อทันที)
1. ให้ผู้ใช้รีเฟรชหน้าเว็บ `http://localhost:3000`
2. ตรวจสอบตัวกรอง "3 จังหวัดชายแดนใต้" จะเห็นโพสต์ของ จ.ยะลา ขึ้นทันที
3. ทดลองตั้งประกาศใหม่โดยเลือก "3 จังหวัดชายแดนใต้" จะมี Dropdown จังหวัด (ยะลา, ปัตตานี, นราธิวาส) ให้เลือก และโพสต์จะเข้าหมวด 3 จังหวัดชายแดนใต้อย่างแม่นยำ 100%
