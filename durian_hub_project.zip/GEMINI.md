# Project Guidelines & Memory Preservation

## 🧠 Context Persistence & Task Tracking Rule (ห้ามลืมงาน & ไม่ต้องอ่านโค้ดซ้ำ)

1. **State-First Workflow**:
   - ทุกครั้งที่เริ่มการตอบ หรือผู้ใช้สั่งงานต่อ ให้ตรวจสอบไฟล์ `CURRENT_TASK.md` ที่ root เสมอ
   - ห้ามเสียเวลา grep หรือ scan อ่านโค้ดทั้งโฟลเดอร์ซ้ำซาก หากข้อมูลสถานะและแผนผังไฟล์มีบันทึกอยู่ใน `CURRENT_TASK.md` แล้ว
   - รู้ทันทีว่า "ตอนนี้ทำอะไรอยู่" และ "ผู้ใช้สั่งอะไรไว้" จากไฟล์นี้

2. **Always Keep `CURRENT_TASK.md` Updated**:
   - เมื่อผู้ใช้มอบหมายงานใหม่ ให้เพิ่ม/อัปเดตลงในส่วน **🎯 Current Goal** และ **📋 Task Checklist**
   - เมื่อทำส่วนใดเสร็จ ให้เช็คถูก `[x]` และปรับ **📍 Where We Are** และ **⏭️ Next Steps** ทันที
   - หากมีการสร้าง/ปรับปรุงไฟล์สำคัญ ให้อัปเดตไว้ใน **🗺️ Key Files & Architecture**

3. **Skill Activation**:
   - ใช้งานร่วมกับ Skill `task-tracker` (`.agents/skills/task-tracker/SKILL.md`) สำหรับบันทึกความจำและงาน
   - ใช้งานร่วมกับ Skill `solution-advisor` (`.agents/skills/solution-advisor/SKILL.md`) เมื่อต้องการคำแนะนำขั้นตอนการพัฒนา, ตรวจสอบจุดบกพร่อง (Defect Audit) และวางแผนแก้โค้ดอย่างเป็นระบบ
